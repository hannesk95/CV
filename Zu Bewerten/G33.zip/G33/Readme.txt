﻿To get started one should read the "README.md".
To do so you could:
* Open it with a Markdown preview software
* Open the "README.html" to preview it in the browser
* Open the GitLab project and preview it there:
https://gitlab.lrz.de/ga24cad/cv-project