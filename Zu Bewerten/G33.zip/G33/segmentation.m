% Segmentation function. Takes a sequence of frames at input.
% Input: left, right - frame sequence tensors
% Output: mask - binary segmentation mask 
function [mask] = segmentation(left,right)

    % Matlab FordergroundDetector GMM
    persistent foregroundDetector;
    if isempty(foregroundDetector)
        foregroundDetector = vision.ForegroundDetector('NumGaussians', 16, ...
        'NumTrainingFrames', 150, 'MinimumBackgroundRatio', 0.4, ...
        'InitialVariance', 30*30, ...
        'AdaptLearningRate', 1);
    end

    %% Get Input frames
    prevFrame = uint8(left(:,:,1:3));
    curFrame = uint8(left(:,:,4:6));
    grayPrevFrame = rgb2gray(prevFrame);
    grayCurFrame = rgb2gray(curFrame);
    
    %% Calculate Masks
    % Frame Difference Mask
    frameDiff = imabsdiff(grayCurFrame, grayPrevFrame);
    maskFrameDiff = frameDiff > 15;

    % Get mask from FordergroundDetector GMM.
    maskGMM = step(foregroundDetector, curFrame); % TODO

    %% Mask Processing
    % Process Frame-Diff Mask. 
    se = strel('square',10);
    maskFrameDiff = imclose(maskFrameDiff,se);

    %% Fusion
    % Apply Mask Fusion
    result  = fusionMask(maskGMM, maskFrameDiff);    
    
    %% Postprocessing 
    se = strel('square',10);
    result = bwareaopen(result, 10);
    result = imclose(result,se);
    result = imfill(result, 'holes');

    mask = result;
end


% Segmentation function. Takes a sequence of frames at input.
% Input: mask_gmm - gmm mask. mask_fd - frame difference mask
% Output: fusion_result - final mask obtained by fusing inputs.
function fusion_result = fusionMask(masks_gmm, masks_fd)

    persistent cpt;
    persistent I_fus;
    if isempty(cpt)
        cpt = zeros(600,800);
        I_fus = -1*ones(600, 800);
    end

    rows = size(masks_gmm, 1);
    cols = size(masks_gmm, 2);

    for j = 1:rows
        for k = 1:cols
            if masks_gmm(j,k) == masks_fd(j,k)
                I_fus(j,k) = masks_fd(j,k);
                cpt(j,k) = 0;
            else
            if cpt(j,k) == 3
                    I_fus(j,k) = masks_gmm(j,k);
                    cpt(j,k) = 0;
            elseif cpt(j,k) == -3        
                    I_fus(j,k) = masks_fd(j,k);
                    cpt(j,k) = 0;
            elseif I_fus(j,k) == masks_gmm(j,k)
                    cpt(j,k) = cpt(j,k) + 1;
            elseif I_fus(j,k) == masks_fd(j,k)
                    cpt(j,k) = cpt(j,k) - 1;
            end
            end
        end
    end

    fusion_result = I_fus;
end