# Computer Vision Challenge 2020
This project realizes a foreground detection algorithm that indentifies human figures passing trough a door portal. A mask is generated that seprates the background, which can be substituted by an user-defined image or color background.

### Group #33
**Authors:**
* Stoyan Margaretov
* Nino Ponchev
* Robert Sander 
* Velimir Todorovski 
* Shyam Shrinivasan

## Instruction: How to start and run the program:
The program can be directly executed using the GUI. Navigate to the directory path of the project. 
Begin by executing *run start_gui.mlapp* or by typing `start_gui` in the command window. The grafic user interface (GIO) will pop-up showing the various input parameters and possible rendering options. 
The following step-by-step guide instructs guide the user on how to execute the algorithm with tested and pre-defined values. The user may change the input as desired. 
> Note: the playback and rendering is of the left-stereo camera images only.

**1.  Source Directory**

Click on the button *Source Directory*. In the pop-up, browse and navigate to the dataset of choice. We have performed our tests with the *P1E_S1* dataset.

**Warning:** If you forget to choose an input directory, the program will not be able to start and you will get an error message. One must choose the dataset directory such that it contains the folders from the three camera perspectives. If the folder selected does not contain three subfolders, an error is thrown that the path is invalid and the program will not start.

**2.  Choosing Cameras**

Choose your preferred "left" perspective between cameras 1 and 2 (recommended: 1) and preferred "right" perspective between cameras 2 and 3 (recommended: 3). 
The GUI will automatically disable camera 2 as an option for the "right" perspective if camera 2 is already selected for the "left".

**3.  Virtual Background**

Navigate to a virtual background of your choice. It must be an `*.jpg` of `*.png` RGB image. The program will automatically adjust the proportions to work with the dataset images. In case you do not choose an image, the GUI will load the default RGB image `default_background.png`.

**4. Output Directory**

Click on the “Output Directory”-button to choose, where the GUI must save the output video (the rendered video).
**Warning:** If you don’t choose any folder you will get an error message and the program will not be able to start.

**5.  Starting Frame**

Enter a frame number to begin with. It is recommended to start with `start=50`, so that the GMM algorithm can learn the background and differentiate human figures better.

**6.  Rendering Mode** 

Choose a rendering mode from the given options: 
* **"foreground":** will keep the moving objects in the image while rendering the background black. 
* **"background":** works the opposite way round as foreground. Here, the object will be turned black while the remaining pixels retain their properties. 
* **"overlay":** induces a transparency in the foreground and background while displaying them in different-colored channels. 
* **"substitute":** replaces the background with the virtual background while the object remains infront. 

**7.  Playback Control**

On the second panel “Playback Control” you can press:

* `Start` to start the playback as well as the rendering process. On the right side in the upper plot window you will see the “Input Video Sequence from the left camera” and in the lower plot window you will see the “Rendered Left Video Sequence”.

* `Stop` to stop the video and the rendering process, at which point the output file will be saved in the *output* directory as "rendered_L.avi". You will also get a pop-up window which tells you again where you can find the rendered video.
> Note: The next rendering process will begin again at the starting index set by the user.

* `Loop` if this switch is turned to `On` the application will begin the video sequence at the starting point input by the user and then continue rendering beyond the end of the folder; looping over to `start=0`. Again if the user wishes to abort the rendering and save the video `Stop` should be pressed.

**8.  Rendered Video Sequence**

The rendered video sequence will be automatically exported to the `output diretory` specified by the user in the `*.avi` format playing at 30 frames/second. 

**10. Reset**
In case the user wishes to change parameters or switch source directories, we recommend that the user uses the `Reset` button before proceeding, in order to ensure that the program executes issue-free.

### Known Issues:

* The input field for "starting frame" depends on the computer's graphics compatibility. Inputting a new value can be buggy on certain computers either experienced through a delay or an inability to edit. 
> **Solution:** Hit "Reset" and try again or minimize and maximize the application's window of the GUI