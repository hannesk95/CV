classdef start_gui_code < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                     matlab.ui.Figure
        UIAxes                       matlab.ui.control.UIAxes
        UIAxes2                      matlab.ui.control.UIAxes
        PlaybackControlPanel         matlab.ui.container.Panel
        StartButton                  matlab.ui.control.Button
        StopButton                   matlab.ui.control.Button
        ResetButton                  matlab.ui.control.Button
        ProgramSettingsPanel         matlab.ui.container.Panel
        SceneDirectoryButton         matlab.ui.control.Button
        VirtualBackgroundButton      matlab.ui.control.Button
        LeftCameraButtonGroup        matlab.ui.container.ButtonGroup
        Button                       matlab.ui.control.RadioButton
        Button_2                     matlab.ui.control.RadioButton
        RightCameraButtonGroup       matlab.ui.container.ButtonGroup
        Button_3                     matlab.ui.control.RadioButton
        Button_4                     matlab.ui.control.RadioButton
        StartingFrameEditFieldLabel  matlab.ui.control.Label
        StartingFrameEditField       matlab.ui.control.NumericEditField
        RenderingModeDropDownLabel   matlab.ui.control.Label
        RenderingModeDropDown        matlab.ui.control.DropDown
        OutputDirectoryButton        matlab.ui.control.Button
        ChooseLabel                  matlab.ui.control.Label
        ChooseLabel_2                matlab.ui.control.Label
        ChooseLabel_3                matlab.ui.control.Label
        ForegroundDetectionLabel     matlab.ui.control.Label
        Group33StoyanNinoRobertVelimirShyamLabel  matlab.ui.control.Label
        XButton                      matlab.ui.control.Button
        LoopSwitchLabel              matlab.ui.control.Label
        LoopSwitch                   matlab.ui.control.Switch
        CurrentFrameEditFieldLabel   matlab.ui.control.Label
        CurrentFrameEditField        matlab.ui.control.NumericEditField
    end

    % Public properties (user-created)
    properties (Access = public)
        src char
        bg double
        stop logical = false
        L uint32 = 1
        R uint32 = 3
        loop logical = false
        start uint32 = 0
        mode string
        output_dir string
        defaultbg double
    end
    
%     properties (Access = private)
%     end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            temp = double(imread('default_background.png')); 
            app.defaultbg = imresize(temp, [600 800]);    
        end

        % Button pushed function: StartButton
        function StartButtonPushed(app, event)
            
            % Error warnings for missing user-input/output directories
            if isempty(app.src) == 1
                msgbox('Scene directory for the input is not selected!','Caution!','warn')
                return
            end
            if isempty(app.output_dir) == 1
                msgbox('Destination directory for the output is not seleted!','Caution!','warn')
                return
            end          
            
            % Reset stop value
            app.stop = false;
            
            % Reading in start index
            app.start = app.StartingFrameEditField.Value;
            
            % Read in rendering mode
            app.mode = app.RenderingModeDropDown.Value;
            
            % Read in loop choice
            if strcmp(app.LoopSwitch.Value, "Off")
            app.loop = false;
            elseif strcmp(app.LoopSwitch.Value, "On")
            app.loop = true;
            end
            
            % Image Reader constructor
            ir = ImageReader(app.src, app.L, app.R, 'start', app.start);               
            
            % Create a VideoWritter object for ".avi" export
            dst_rendered_L = fullfile(app.output_dir, '/rendered_L.avi');
            v_rendered_L = VideoWriter(dst_rendered_L,'Motion JPEG AVI');
            v_rendered_L.FrameRate = 30;  % Default 30
            v_rendered_L.Quality = 50;    % Default 75
            
            % Initialize Main Loop
            v_rendered_L.open;           
            end_of_data = false;
            
            while app.stop == false && ( end_of_data == false || app.loop == true )                  
                      
                    % Display the current frame ID
                    current_frame = ir.start;
                    app.CurrentFrameEditField.Value = double(current_frame);
                
                    % Load 2 frames from the scene
                    [images_L, images_R, end_of_data] = ir.next();
                    
                    % Perform the segmentation
                    mask = segmentation(images_L, images_R);
                    
                    %Render first frame
                    if ~isempty(app.bg)
                        frame_L_rendered_1 = render(images_L(:,:,1:3), mask, app.mode, app.bg);
                    else
                        frame_L_rendered_1 = render(images_L(:,:,1:3), mask, app.mode, app.defaultbg);
                    end
                    %Render second frame
                    if ~isempty(app.bg)
                        frame_L_rendered_2 = render(images_L(:,:,4:6), mask, app.mode, app.bg);
                    else
                        frame_L_rendered_2 = render(images_L(:,:,4:6), mask, app.mode, app.defaultbg);
                    end
                    
                    %Show first frame (unrendered)
                    imshow( uint8( images_L(:,:,1:3) ), 'Parent', app.UIAxes);
                    pause(0.05)             
                    
                    %Show first frame (rendered)
                    im = imshow( uint8( frame_L_rendered_1 ), 'Parent', app.UIAxes2);
                    if app.mode == "Overlay"
                       im.AlphaData = 0.3; 
                    end
                    pause(0.05)
                
                    %Show current frame ID
                    app.CurrentFrameEditField.Value = double(current_frame + 1);
                    
                    %Show second frame (unrendered)
                    imshow( uint8( images_L(:,:,4:6) ), 'Parent', app.UIAxes);
                    pause(0.05)             
                    
                    %Show second frame (rendered)
                    im = imshow( uint8( frame_L_rendered_2 ), 'Parent', app.UIAxes2);
                    if app.mode == "Overlay"
                       im.AlphaData = 0.3; 
                    end
                    pause(0.05)
                    
                    % Write first frame to VideoWriter object
                    writeVideo(v_rendered_L, ...
                        reshape(frame_L_rendered_1, ...
                        size(frame_L_rendered_1,1), ...
                        size(frame_L_rendered_1,2), 3, ... 
                        size(frame_L_rendered_1,3)/3) );
                    % Write second frame to VideoWriter object
                    writeVideo(v_rendered_L, ...
                        reshape(frame_L_rendered_2, ...
                        size(frame_L_rendered_2,1), ...
                        size(frame_L_rendered_2,2), 3, ... 
                        size(frame_L_rendered_2,3)/3) );
                    
            end       
            
            % Clear persistent variables
            clear fusionMask
            clear segmentation
            
            % Close VideoWritter and export video
            v_rendered_L.close;
            
            %pop-up message - Output video is exported + path!
            msgbox( {'The output video is exported in:', ('" ' + app.output_dir + ' " !') }, 'Rendering process is completed!', 'help');
            
        end

        % Button pushed function: StopButton
        function StopButtonPushed(app, event)
            
            % Break the rendering loop
            app.stop = true;
            
        end

        % Value changed function: RenderingModeDropDown
        function RenderingModeDropDownValueChanged(app, event)

            app.mode = app.RenderingModeDropDown.Value;
            
        end

        % Button pushed function: SceneDirectoryButton
        function SceneDirectoryButtonPushed(app, event)
            app.src = uigetdir('../', 'Choose a source directory');
            %Check if there are exactly 3 folders in the scene directory
            all_files = dir(app.src);
            all_dir = all_files([all_files(:).isdir]);
            num_dir = numel(all_dir);
            temp = num_dir;
            
            for i = 1 : temp
            if all( all_dir(i).name == "." ) || all(all_dir(i).name == "..")
                num_dir = num_dir - 1;
            end
            end
            
            assert(num_dir==3, "Scene order structer is invalid! Exactly three folders are expected!")
            clear num_dir all_dir temp all_files
            
        end

        % Button pushed function: VirtualBackgroundButton
        function VirtualBackgroundButtonPushed(app, event)
            [bg_link, bg_path] = uigetfile({'*.png'; '*.jpg'},...
                'Choose a virtual background');
            app.bg = double(imread(fullfile(bg_path, bg_link)));
            
            % check if it's an RGB image
            assert(size(app.bg, 3) == 3, "Too few channels. Image must be RGB!")
            % reshape to 600x800x3
            app.bg = imresize(app.bg, [600 800]);
          
        end

        % Selection changed function: LeftCameraButtonGroup
        function LeftCameraButtonGroupSelectionChanged(app, event)
            selectedButton = app.LeftCameraButtonGroup.SelectedObject;
            app.L = str2num(selectedButton.Text);
            if selectedButton == app.Button_2               
                set(app.Button_3, 'Enable', 'off');
            else
                set(app.Button_3, 'Enable', 'on')
            end
        end

        % Selection changed function: RightCameraButtonGroup
        function RightCameraButtonGroupSelectionChanged(app, event)
            selectedButton = app.RightCameraButtonGroup.SelectedObject;
            app.R = str2num(selectedButton.Text);            
        end

        % Value changed function: StartingFrameEditField
        function StartingFrameEditFieldValueChanged(app, event)
            % Reading in start index
            app.start = app.StartingFrameEditField.Value;
            assert(app.start>=0, 'Start index must be nonnegative')
            % Update current frame numeric field
            app.CurrentFrameEditField.Value = double(app.start);
        end

        % Button pushed function: ResetButton
        function ResetButtonPushed(app, event)
            close(app.UIFigure);
            start_gui;
        end

        % Button pushed function: XButton
        function XButtonPushed(app, event)
            if ~isempty(v_rendered_L)
                v_rendered_L.close;
           end      
            close(app.UIFigure); close all;
            clear; clc;
        end

        % Value changed function: LoopSwitch
        function LoopSwitchValueChanged(app, event)
            value = app.LoopSwitch.Value;
            if strcmp(value, "Off")
            app.loop = false;
            elseif strcmp(value, "On")
            app.loop = true;
            end
        end

        % Button pushed function: OutputDirectoryButton
        function OutputDirectoryButtonPushed(app, event)
            app.output_dir = uigetdir('../', 'Choose a directory for the rendered video!');          
            assert(isempty(app.output_dir) == 0, "Destination directory for the output required!")
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 701 580];
            app.UIFigure.Name = 'MATLAB App';

            % Create UIAxes
            app.UIAxes = uiaxes(app.UIFigure);
            title(app.UIAxes, 'Left Stereo Input Video Sequence')
            xlabel(app.UIAxes, '')
            ylabel(app.UIAxes, '')
            app.UIAxes.PlotBoxAspectRatio = [1.94615384615385 1 1];
            app.UIAxes.Position = [341 249 345 213];

            % Create UIAxes2
            app.UIAxes2 = uiaxes(app.UIFigure);
            title(app.UIAxes2, 'Rendered Left Stereo Video Sequence')
            xlabel(app.UIAxes2, '')
            ylabel(app.UIAxes2, '')
            app.UIAxes2.PlotBoxAspectRatio = [1.94615384615385 1 1];
            app.UIAxes2.Position = [341 37 345 213];

            % Create PlaybackControlPanel
            app.PlaybackControlPanel = uipanel(app.UIFigure);
            app.PlaybackControlPanel.TitlePosition = 'centertop';
            app.PlaybackControlPanel.Title = 'Playback Control';
            app.PlaybackControlPanel.BackgroundColor = [0.8 0.8 0.8];
            app.PlaybackControlPanel.FontWeight = 'bold';
            app.PlaybackControlPanel.FontSize = 14;
            app.PlaybackControlPanel.Position = [25 14 285 116];

            % Create StartButton
            app.StartButton = uibutton(app.PlaybackControlPanel, 'push');
            app.StartButton.ButtonPushedFcn = createCallbackFcn(app, @StartButtonPushed, true);
            app.StartButton.FontWeight = 'bold';
            app.StartButton.Position = [13 59 62 22];
            app.StartButton.Text = 'Start';

            % Create StopButton
            app.StopButton = uibutton(app.PlaybackControlPanel, 'push');
            app.StopButton.ButtonPushedFcn = createCallbackFcn(app, @StopButtonPushed, true);
            app.StopButton.FontWeight = 'bold';
            app.StopButton.Position = [111 59 61 22];
            app.StopButton.Text = 'Stop';

            % Create ResetButton
            app.ResetButton = uibutton(app.PlaybackControlPanel, 'push');
            app.ResetButton.ButtonPushedFcn = createCallbackFcn(app, @ResetButtonPushed, true);
            app.ResetButton.FontWeight = 'bold';
            app.ResetButton.Position = [218 59 60 22];
            app.ResetButton.Text = 'Reset';

            % Create ProgramSettingsPanel
            app.ProgramSettingsPanel = uipanel(app.UIFigure);
            app.ProgramSettingsPanel.TitlePosition = 'centertop';
            app.ProgramSettingsPanel.Title = 'Program Settings';
            app.ProgramSettingsPanel.BackgroundColor = [0.8 0.8 0.8];
            app.ProgramSettingsPanel.FontName = 'MS Sans Serif';
            app.ProgramSettingsPanel.FontWeight = 'bold';
            app.ProgramSettingsPanel.FontSize = 14;
            app.ProgramSettingsPanel.Position = [25 143 284 346];

            % Create SceneDirectoryButton
            app.SceneDirectoryButton = uibutton(app.ProgramSettingsPanel, 'push');
            app.SceneDirectoryButton.ButtonPushedFcn = createCallbackFcn(app, @SceneDirectoryButtonPushed, true);
            app.SceneDirectoryButton.FontWeight = 'bold';
            app.SceneDirectoryButton.Position = [66 280 155 22];
            app.SceneDirectoryButton.Text = 'Scene Directory';

            % Create VirtualBackgroundButton
            app.VirtualBackgroundButton = uibutton(app.ProgramSettingsPanel, 'push');
            app.VirtualBackgroundButton.ButtonPushedFcn = createCallbackFcn(app, @VirtualBackgroundButtonPushed, true);
            app.VirtualBackgroundButton.FontWeight = 'bold';
            app.VirtualBackgroundButton.Position = [64 170 155 22];
            app.VirtualBackgroundButton.Text = 'Virtual Background';

            % Create LeftCameraButtonGroup
            app.LeftCameraButtonGroup = uibuttongroup(app.ProgramSettingsPanel);
            app.LeftCameraButtonGroup.SelectionChangedFcn = createCallbackFcn(app, @LeftCameraButtonGroupSelectionChanged, true);
            app.LeftCameraButtonGroup.TitlePosition = 'centertop';
            app.LeftCameraButtonGroup.Title = 'Left Camera';
            app.LeftCameraButtonGroup.FontName = 'MS Sans Serif';
            app.LeftCameraButtonGroup.FontWeight = 'bold';
            app.LeftCameraButtonGroup.Position = [31 208 100 54];

            % Create Button
            app.Button = uiradiobutton(app.LeftCameraButtonGroup);
            app.Button.Text = '1';
            app.Button.Position = [19 7 34 22];
            app.Button.Value = true;

            % Create Button_2
            app.Button_2 = uiradiobutton(app.LeftCameraButtonGroup);
            app.Button_2.Text = '2';
            app.Button_2.Position = [52 7 48 22];

            % Create RightCameraButtonGroup
            app.RightCameraButtonGroup = uibuttongroup(app.ProgramSettingsPanel);
            app.RightCameraButtonGroup.SelectionChangedFcn = createCallbackFcn(app, @RightCameraButtonGroupSelectionChanged, true);
            app.RightCameraButtonGroup.TitlePosition = 'centertop';
            app.RightCameraButtonGroup.Title = 'Right Camera';
            app.RightCameraButtonGroup.FontName = 'MS Sans Serif';
            app.RightCameraButtonGroup.FontWeight = 'bold';
            app.RightCameraButtonGroup.Position = [153 208 100 54];

            % Create Button_3
            app.Button_3 = uiradiobutton(app.RightCameraButtonGroup);
            app.Button_3.Text = '2';
            app.Button_3.Position = [19 7 34 22];

            % Create Button_4
            app.Button_4 = uiradiobutton(app.RightCameraButtonGroup);
            app.Button_4.Text = '3';
            app.Button_4.Position = [51 7 48 22];
            app.Button_4.Value = true;

            % Create StartingFrameEditFieldLabel
            app.StartingFrameEditFieldLabel = uilabel(app.ProgramSettingsPanel);
            app.StartingFrameEditFieldLabel.HorizontalAlignment = 'right';
            app.StartingFrameEditFieldLabel.FontWeight = 'bold';
            app.StartingFrameEditFieldLabel.Position = [62 71 90 22];
            app.StartingFrameEditFieldLabel.Text = 'Starting Frame';

            % Create StartingFrameEditField
            app.StartingFrameEditField = uieditfield(app.ProgramSettingsPanel, 'numeric');
            app.StartingFrameEditField.ValueChangedFcn = createCallbackFcn(app, @StartingFrameEditFieldValueChanged, true);
            app.StartingFrameEditField.Position = [170 71 62 22];
            app.StartingFrameEditField.Value = 200;

            % Create RenderingModeDropDownLabel
            app.RenderingModeDropDownLabel = uilabel(app.ProgramSettingsPanel);
            app.RenderingModeDropDownLabel.HorizontalAlignment = 'center';
            app.RenderingModeDropDownLabel.FontWeight = 'bold';
            app.RenderingModeDropDownLabel.Position = [40 20 100 22];
            app.RenderingModeDropDownLabel.Text = 'Rendering Mode';

            % Create RenderingModeDropDown
            app.RenderingModeDropDown = uidropdown(app.ProgramSettingsPanel);
            app.RenderingModeDropDown.Items = {'foreground', 'background', 'overlay', 'substitute'};
            app.RenderingModeDropDown.ValueChangedFcn = createCallbackFcn(app, @RenderingModeDropDownValueChanged, true);
            app.RenderingModeDropDown.Position = [147 20 106 23];
            app.RenderingModeDropDown.Value = 'foreground';

            % Create OutputDirectoryButton
            app.OutputDirectoryButton = uibutton(app.ProgramSettingsPanel, 'push');
            app.OutputDirectoryButton.ButtonPushedFcn = createCallbackFcn(app, @OutputDirectoryButtonPushed, true);
            app.OutputDirectoryButton.FontWeight = 'bold';
            app.OutputDirectoryButton.Position = [64 125 155 22];
            app.OutputDirectoryButton.Text = 'Output Directory';

            % Create ChooseLabel
            app.ChooseLabel = uilabel(app.ProgramSettingsPanel);
            app.ChooseLabel.HorizontalAlignment = 'right';
            app.ChooseLabel.Position = [7 280 50 22];
            app.ChooseLabel.Text = 'Choose:';

            % Create ChooseLabel_2
            app.ChooseLabel_2 = uilabel(app.ProgramSettingsPanel);
            app.ChooseLabel_2.HorizontalAlignment = 'right';
            app.ChooseLabel_2.Position = [7 170 50 22];
            app.ChooseLabel_2.Text = 'Choose:';

            % Create ChooseLabel_3
            app.ChooseLabel_3 = uilabel(app.ProgramSettingsPanel);
            app.ChooseLabel_3.HorizontalAlignment = 'right';
            app.ChooseLabel_3.Position = [7 125 50 22];
            app.ChooseLabel_3.Text = 'Choose:';

            % Create ForegroundDetectionLabel
            app.ForegroundDetectionLabel = uilabel(app.UIFigure);
            app.ForegroundDetectionLabel.FontName = 'Lato Light';
            app.ForegroundDetectionLabel.FontSize = 32;
            app.ForegroundDetectionLabel.FontWeight = 'bold';
            app.ForegroundDetectionLabel.Position = [25 511 431 50];
            app.ForegroundDetectionLabel.Text = 'Foreground Detection';

            % Create Group33StoyanNinoRobertVelimirShyamLabel
            app.Group33StoyanNinoRobertVelimirShyamLabel = uilabel(app.UIFigure);
            app.Group33StoyanNinoRobertVelimirShyamLabel.FontName = 'Lato Light';
            app.Group33StoyanNinoRobertVelimirShyamLabel.FontAngle = 'italic';
            app.Group33StoyanNinoRobertVelimirShyamLabel.Position = [423 14 263 22];
            app.Group33StoyanNinoRobertVelimirShyamLabel.Text = 'Group 33: Stoyan, Nino, Robert, Velimir, Shyam';

            % Create XButton
            app.XButton = uibutton(app.UIFigure, 'push');
            app.XButton.ButtonPushedFcn = createCallbackFcn(app, @XButtonPushed, true);
            app.XButton.IconAlignment = 'center';
            app.XButton.BackgroundColor = [0.902 0.902 0.902];
            app.XButton.FontName = 'Lato Black';
            app.XButton.FontWeight = 'bold';
            app.XButton.Position = [650.5 539 25 22];
            app.XButton.Text = 'X';

            % Create LoopSwitchLabel
            app.LoopSwitchLabel = uilabel(app.UIFigure);
            app.LoopSwitchLabel.HorizontalAlignment = 'center';
            app.LoopSwitchLabel.Position = [72 37 36 22];
            app.LoopSwitchLabel.Text = 'Loop:';

            % Create LoopSwitch
            app.LoopSwitch = uiswitch(app.UIFigure, 'slider');
            app.LoopSwitch.ValueChangedFcn = createCallbackFcn(app, @LoopSwitchValueChanged, true);
            app.LoopSwitch.Position = [143 38 45 20];

            % Create CurrentFrameEditFieldLabel
            app.CurrentFrameEditFieldLabel = uilabel(app.UIFigure);
            app.CurrentFrameEditFieldLabel.HorizontalAlignment = 'right';
            app.CurrentFrameEditFieldLabel.Position = [413 476 87 22];
            app.CurrentFrameEditFieldLabel.Text = 'Current Frame:';

            % Create CurrentFrameEditField
            app.CurrentFrameEditField = uieditfield(app.UIFigure, 'numeric');
            app.CurrentFrameEditField.Position = [515 476 100 22];

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = start_gui_code

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end