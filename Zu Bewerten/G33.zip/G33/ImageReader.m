   classdef ImageReader < handle
    %% Declare properties
    properties 
        src char % Source link 
        src_C_left char % path to left camera data
        src_C_right char % path to right camera data
        filenames_C_left char %List of all the filenames of left camera
        filenames_C_right char %List of all the filenames of left camera
        num_images uint32 {mustBeNonnegative}; % Number of images in a dataset
        
        P uint32 {mustBeNonnegative} % Portal number
        E_L char % Entry = 'E', Leave = 'L'
        S uint32 {mustBeNonnegative} % Scene number       
        L uint32 {mustBeGreaterThanOrEqual(L, 1), mustBeLessThanOrEqual(L, 2)} = 1 % L = {1,2} (optl: set default to 1 (arbitrary))
        R uint32 {mustBeGreaterThanOrEqual(R, 2), mustBeLessThanOrEqual(R, 3)} = 2 % R = {2,3} (optl: set default to 2 (arbitrary))
               
        start uint32 {mustBeNonnegative} = 0 % start-index for date reading
        N uint32 {mustBeNonnegative} = 1 % No. of following images to be loaded
        
        left double {mustBeReal, mustBeFinite} % tensor containing data from the "left" of stereo camera
        right double {mustBeReal, mustBeFinite} % tensor containing data from the "right" of stereo camera
    end
    
    %% Define Methods
    methods      
        %% Constructor
        function obj = ImageReader(src, L , R, varargin)
            obj.src = src;
            obj.L = L;
            obj.R = R;
            
            p = inputParser;
            %Case sensitivity
            p.CaseSensitive = false;

            %Definining default values
            defaultN= 1;
            defaultStart = 0;

            %Declaring {'Name','Value'}
            addParameter(p, 'N', defaultN);
            addParameter(p, 'start', defaultStart);
            
            %Parsing the varargin agruement
            parse(p,varargin{:});

            %Storing the parsed values in parameters
            obj.N = p.Results.N;
            obj.start = p.Results.start;
            
            %Parse scene-specific indices
            P_ind = find(obj.src == 'P', 1, 'last');
            obj.P = str2num(obj.src(P_ind+1));
            obj.E_L = src(P_ind+2);            
            S_ind = find(obj.src == 'S', 1, 'last');
            obj.S = str2num(obj.src(S_ind+1));
                       
            %Defining left and right camera folder
            obj.src_C_left = [src, '/P', src(P_ind+1), src(P_ind+2),...
                       '_S', src(S_ind+1), '_C', num2str(obj.L)];
            obj.src_C_right = [src, '/P', src(P_ind+1), src(P_ind+2),...
                       '_S', src(S_ind+1), '_C', num2str(obj.R)];
            
            %Filename lists
            FileList = dir(fullfile(obj.src_C_left, '/*.jpg'));
            obj.filenames_C_left = {FileList.name};
            FileList = dir(fullfile(obj.src_C_right, '/*.jpg'));
            obj.filenames_C_right = {FileList.name};
            
            %Number of Images
            obj.num_images = size( obj.filenames_C_left, 1 );
            assert( obj.num_images == size( obj.filenames_C_left, 1 ),...
                    'Number of images of left and right camer must be the same!');
            assert( obj.start < obj.num_images-1,...
                    'Start index should be smaller than the number of elements!');
        end
        
        %% Load images
        function [left, right, loop] = next(obj)
                       
            % If enough images in filelist
            if obj.start + obj.N <= obj.num_images -1
                
                % (N+1) RGB images of left and right cameras
                left = zeros(600, 800, (obj.N + 1) * 3); 
                right = zeros(600, 800, (obj.N + 1) * 3); 
                
                k = 0; % seperate counter to increase value by 1 - to get next image
                for i = 1:3:(obj.N + 1) * 3
                    ind = obj.start + k + 1; % +1 because of MATLAB's 1-based notation
                    left(:, :, i:i+2)  = imread( fullfile( obj.src_C_left, obj.filenames_C_left(ind,:) ));
                    right(:, :, i:i+2) = imread( fullfile( obj.src_C_left, obj.filenames_C_left(ind,:) ));
                    k = k + 1;
                end
                
                % If filelist end not yet reached
                if obj.start + obj.N < obj.num_images -1
                    obj.start = obj.start + obj.N + 1; % update start value so that it picks up from here in the next call of next()
                    loop = 0;
                else
                    obj.start = 0; % start is 0, since it's the end of the dataset
                    loop = 1; % turn loop to 1, since it's the end of dataset
                end
                
            else   
                diff = obj.num_images - obj.start;
                % (N+1) RGB images of left and right cameras
                left = zeros(600, 800, diff * 3); 
                right = zeros(600, 800, diff * 3); 
                k = 0;                
                for i = 1:3:diff*3
                    ind = obj.start + k + 1;
                    left(:, :, i:i+2)  = imread( fullfile( obj.src_C_left, obj.filenames_C_left(ind,:) ));
                    right(:, :, i:i+2) = imread( fullfile( obj.src_C_left, obj.filenames_C_left(ind,:) ));
                    k = k + 1;
                end   
                obj.start = 0; % start is 1, since it's the end of the dataset   
                loop = 1; % turn loop to 1, since it's the end of dataset                
            end 
            left = double(left);
            right = double(right);
            
        end 
        
    end    
end