%% Computer Vision Challenge 2020 challenge.m

%% Initialization
config

if store == true
  v_rendered_L = VideoWriter(dest ,'Motion JPEG AVI');
  v_rendered_L.FrameRate = 30;  % Default 30
  v_rendered_L.Quality = 50;    % Default 75
end

%% Open the VideoWritter Object
if store==1
v_rendered_L.open;
end

%% Start timer here
tic

%% Generate Movie

% Initialize Main Loop      
end_of_data = false;

while end_of_data == false                

    % Display the current frame ID
    fprintf( 'Currently processing frame %d of %d \n', ir.start, ir.num_images-1 );
    fprintf( 'Currently processing frame %d of %d \n', ir.start+1, ir.num_images-1 );

    % Load 2 frames from the scene
    [images_L, images_R, end_of_data] = ir.next();

    % Perform the segmentation
    mask = segmentation(images_L, images_R);

    %Render first frame
        frame_L_rendered_1 = render(images_L(:,:,1:3), mask, render_mode, bg);
    
    %Render second frame
        frame_L_rendered_2 = render(images_L(:,:,4:6), mask, render_mode, bg);

    % Write first frame to VideoWriter object
    writeVideo(v_rendered_L, ...
        reshape(frame_L_rendered_1, ...
        size(frame_L_rendered_1,1), ...
        size(frame_L_rendered_1,2), 3, ... 
        size(frame_L_rendered_1,3)/3) );
    % Write second frame to VideoWriter object
    writeVideo(v_rendered_L, ...
        reshape(frame_L_rendered_2, ...
        size(frame_L_rendered_2,1), ...
        size(frame_L_rendered_2,2), 3, ... 
        size(frame_L_rendered_2,3)/3) );

end       

%% Stop timer here
elapsed_time = toc

%% Close VideoWritter and export video
v_rendered_L.close;

%% Clear persistent variables
clear fusionMask
clear segmentation
