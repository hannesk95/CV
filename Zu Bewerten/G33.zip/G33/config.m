%% Computer Vision Challenge 2020 config.m
clear; close all; clc;
%% Generall Settings
% Group number:
group_number = 33;

% Group members:
members = {'Stoyan Margaretov', 'Robert Sander', 'Nino Ponchev',...
           'Shyam Shrinivasan', 'Velimir Todorovski'};

% Email-Address (from Moodle!):
mail = {'ga24cad@mytum.de', 'ga26zuj@mytum.de', 'ga65fud@mytum.de',...
        'ga47tob@mytum.de', 'ge75haz@mytum.de'};


%% Setup Image Reader
% Specify Scene Folder
src = '../ChokePoint/P1E_S1';

% Select Cameras
L = 1;
R = 3;

% Choose a start point
start = 0;

% Choose the number of succseeding frames
N = 1;

% Instantiating an ImageReader object
ir = ImageReader(src, L, R, 'start', start, 'N', N);


%% Output Settings
% Output Path
dest = './output/rendered_L.avi';

% Load Virual Background
bg = imread("./default_background.png");

% Select rendering mode
render_mode = "substitute";

% Store Output?
store = true;

% Create a VideoWritter object for ".avi" export
            v_rendered_L = VideoWriter(dest,'Motion JPEG AVI');
            v_rendered_L.FrameRate = 30;  % Default 30
            v_rendered_L.Quality = 50;    % Default 75
