function [result_uint8] = render(frame, mask, render_mode, bg)

    % Converting the frame to double
    bg = double(bg);

    % Converting the fram to double
    frame = double(frame);
    
    % Duplication mask for all RGB channels
    mask_3C = cat(3, mask, mask, mask);
    
    switch render_mode
        case "foreground"
            result = mask_3C .* frame;
        case "background"
            result = ~mask_3C .* frame; % Alternative: mask = 1 - mask;
        case "overlay"
            b = zeros(size(frame, 1), size(frame, 2)); % create black matrix
            red_fg = (mask_3C .* frame); % separate foreground
            red_fg = red_fg(:, :, 1); % red channel foreground
            blue_bg = (~mask_3C .* frame); % separate background 
            blue_bg = blue_bg(:, :, 3); % blue channel background 
            result = cat(3, red_fg, b, blue_bg);
        case "substitute"
            result = (mask_3C .* frame) + (~mask_3C .* bg);
        otherwise
            error('Non-existing rendering mode has been chosen');
    end
    
    % Convert result back to uint8
    result_uint8 = uint8(result);
    
end
