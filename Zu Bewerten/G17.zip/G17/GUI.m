function varargout = GUI(varargin)

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI is made visible.
function GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI (see VARARGIN)

% Choose default command line output for GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Callback



% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Select Camera button
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
data.cam_dir = uigetdir('C:\');



% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over text2.
function text2_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to text2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function text2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in startButton.
function startButton_Callback(hObject, eventdata, handles)
% hObject    handle to startButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global dest;

global save;
yes = get(handles.yesButton,'Value');
no = get(handles.noButton,'Value');

if yes == 1 && no == 0
    save = 1;
    dest = strcat(get(handles.fileText,'String'),'.avi')
else
    save = 0;
end

global path;
path = get(handles.pathStaticText, 'String');
% Background Image
global background;
background = handles.background;
assignin('base','background',background);

global camL;
global camR;

% Left and Right Camera indices
if get(handles.leftCam_1, 'Value') == 1
    camL = 1;
elseif get(handles.leftCam_2, 'Value') == 1 && get(handles.rightCam_2, 'Value') ~= 1
    camL = 2;
else
    error('Cannot use same camera for left and right video stream!')
end
if get(handles.rightCam_2, 'Value') == 1 && get(handles.leftCam_2, 'Value') ~= 1
    camR = 2;
elseif get(handles.rightCam_3, 'Value') == 1
    camR = 3;
else
    error('Cannot use same camera for left and right video stream!')
end
% Rendering Mode index
global renderingMode;
rendMod = get(handles.renderingModeMenu, 'Value');
switch rendMod
    case 1
        renderingMode = 'foreground';
    case 2
        renderingMode = 'background';
    case 3
        renderingMode = 'overlay';
    case 4
        renderingMode = 'substitute';
    case 5
        renderingMode = 'video';
end
global start
start = get(handles.startValueEditText, 'String');
start = str2double(start);
global N;
N = get(handles.NEditText,'String');
N = str2double(N);
assignin('base','renderingMode',renderingMode);
assignin('base','camL',camL);
assignin('base','camR',camR);
assignin('base','path',path);
assignin('base','start',start);
assignin('base','N',N);
% Render Here
global ir;
ir = ImageReader(path,camL,camR,start,N);

global play;
play = 1;
global a;
a = 3*start + 1;
global looping;
loop = 0;

if looping == 0
    tic
    while loop ~= 1
        if play == 0
            break;
        end
        % Load Next Images
        [left, right, loop] = ir.next();
        imshow(uint8(left(:,:,1:3)),'Parent',handles.leftAxes)
        imshow(uint8(right(:,:,1:3)),'Parent',handles.rightAxes)
        drawnow
        
        % Segmentation
        mask = segmentation(left,right);
        
        % Rendering
        axes(handles.renderAxes);
        result = render_gui(left,mask,background,renderingMode);
        
        a = a + 3
        
    end
    toc
    
else
    while 1
        if play == 0
            break;
        end
        % Load Next Images
        [left, right, loop] = ir.next();
        imshow(uint8(left(:,:,1:3)),'Parent',handles.leftAxes)
        imshow(uint8(right(:,:,1:3)),'Parent',handles.rightAxes)
        drawnow
        
        % Segmentation
        mask = segmentation(left,right);
        
        % Rendering
        axes(handles.renderAxes);
        result = render_gui(left,mask,background,renderingMode);
        
        a = a + 3
        
    end 
end

if save
  v=VideoWriter(dest);     %Create avi video object，it is empty at the beginning
  v.FrameRate=30;          %define the frameramte of the video
  open(v);                 %Open file for writing video data
  writeVideo(v,result);   %write the video step by step
end

set(handles.loopCheckbox,'Value',loop);

% --- Executes on button press in stopButton.
function stopButton_Callback(hObject, eventdata, handles)
% hObject    handle to stopButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global play
play = 0;
global loop
loop = 0;
set(handles.loopCheckbox,'Value',loop);
global a;
global start;
a = 2*start + 1;

% --- Executes on button press in loopButton.
function loopButton_Callback(hObject, eventdata, handles)
% hObject    handle to loopButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global looping;
if looping == 0
   looping = 1;
elseif looping == 1
   looping = 0;
else
    looping = 0;
end
set(handles.loopCheckbox,'Value',looping);

% --- Executes on button press in cameraDirectoryButton.
function cameraDirectoryButton_Callback(hObject, eventdata, handles)
% hObject    handle to cameraDirectoryButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selpath = uigetdir();
handles.selpath = selpath;
set(handles.pathStaticText, 'String', selpath);



% --- Executes on button press in leftCam_2.
function leftCam_2_Callback(hObject, eventdata, handles)
% hObject    handle to leftCam_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of leftCam_2


% --- Executes on button press in leftCam_1.
function leftCam_1_Callback(hObject, eventdata, handles)
% hObject    handle to leftCam_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of leftCam_1



function startValueEditText_Callback(hObject, eventdata, handles)
% hObject    handle to startValueEditText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startValueEditText as text
%        str2double(get(hObject,'String')) returns contents of startValueEditText as a double


% --- Executes during object creation, after setting all properties.
function startValueEditText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startValueEditText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton14.
function pushbutton14_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function pathStaticText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pathStaticText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on selection change in renderingPopUpMenu.
function renderingPopUpMenu_Callback(hObject, eventdata, handles)
% hObject    handle to renderingPopUpMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns renderingPopUpMenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from renderingPopUpMenu


% --- Executes during object creation, after setting all properties.
function renderingPopUpMenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to renderingPopUpMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in renderingModeMenu.
function renderingModeMenu_Callback(hObject, eventdata, handles)
% hObject    handle to renderingModeMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns renderingModeMenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from renderingModeMenu


% --- Executes during object creation, after setting all properties.
function renderingModeMenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to renderingModeMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in backgroundButton.
function backgroundButton_Callback(hObject, eventdata, handles)
% hObject    handle to backgroundButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[file, path] = uigetfile({'*.png; *.PNG; *.jpg; *.JPG; *.jpeg; *.JPEG; *.img; *.IMG; *.tif; *.TIF; *.tiff, *.TIFF; *.MP4; *.mp4','Supported Files (*.jpg,*.img,*.tiff,*.png,*.mp4)'; ...
    '*.jpg','jpg Files (*.jpg)';...
    '*.JPG','JPG Files (*.JPG)';...
    '*.jpeg','jpeg Files (*.jpeg)';...
    '*.JPEG','JPEG Files (*.JPEG)';...
    '*.img','img Files (*.img)';...
    '*.IMG','IMG Files (*.IMG)';...
    '*.tif','tif Files (*.tif)';...
    '*.TIF','TIF Files (*.TIF)';...
    '*.tiff','tiff Files (*.tiff)';...
    '*.TIFF','TIFF Files (*.TIFF)';...
    '*.png', 'png Files (*.png)';...
    '*.PNG', 'PNG Files (*.PNG)';...
    '*.mp4', 'mp4 Files (*.mp4)';...
    '*.MP4', 'MP4 Files (*.MP4)'});

if file ~= 0
    bgPath = (strcat(path,file));
    [f,p,ext] = fileparts(bgPath);
    switch ext
        case '.mp4'
            v = VideoReader(bgPath);
            video = read(v);
            numRows     = size(video, 1);
            numCols     = size(video, 2);
            numChannels = size(video, 3);
            numFrames   = size(video, 4);
            vid = reshape(video, [(numRows), numCols, numChannels*numFrames]);
            newVid = zeros(600,800,size(vid,3));
            f = waitbar(0, 'Load Video');
            for i = 1:size(vid,3)
               newVid(:,:,i) = imresize(vid(:,:,i),[600, 800]); 
               waitbar(100*i/size(vid,3))
            end
            close(f);
            handles.video = newVid;
            handles.background = bgPath;
            assignin('base','newVid',newVid);
        case'.MP4'
            v = VideoReader(bgPath);
            video = read(v);
            numRows     = size(video, 1);
            numCols     = size(video, 2);
            numChannels = size(video, 3);
            numFrames   = size(video, 4);
            vid = reshape(video, [(numRows), numCols, numChannels * numFrames]);
            newVid = zeros(600,800,size(vid,3));
            f = waitbar(0, 'Load Video');
            for i = 1:size(vid,3)
               newVid(:,:,i) = imresize(vid(:,:,i),[600, 800]);
               waitbar(100*i/size(vid,3))
            end
            close(f);
            handles.video = newVid;
            handles.background = bgPath;
            assignin('base','newVid',newVid);
        otherwise
            handles.background = imread(bgPath);
    end

    guidata(hObject, handles);
    set(handles.previewButton,'Enable','on');
end


% --- Executes on button press in previewButton.
function previewButton_Callback(hObject, eventdata, handles)
% hObject    handle to previewButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
previewFigure = figure;
if (~isempty(handles.video))
    for i = 1:3:size(handles.video)
       imshow(handles.video(:,:,i:i+2)); 
    end
else
    imshow(handles.background(:,:,1:3));
end


% --- Executes on button press in renderButton.
function renderButton_Callback(hObject, eventdata, handles)
% hObject    handle to renderButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
guidata(hObject, handles);
% Video Stream Path String


function NEditText_Callback(hObject, eventdata, handles)
% hObject    handle to NEditText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of NEditText as text
%        str2double(get(hObject,'String')) returns contents of NEditText as a double


% --- Executes during object creation, after setting all properties.
function NEditText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NEditText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in loopCheckbox.
function loopCheckbox_Callback(hObject, eventdata, handles)
% hObject    handle to loopCheckbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of loopCheckbox


% --- Executes on button press in saveButton.
function saveButton_Callback(hObject, eventdata, handles)
% hObject    handle to saveButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function fileText_Callback(hObject, eventdata, handles)
% hObject    handle to fileText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fileText as text
%        str2double(get(hObject,'String')) returns contents of fileText as a double


% --- Executes during object creation, after setting all properties.
function fileText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fileText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in yesButton.
function yesButton_Callback(hObject, eventdata, handles)
% hObject    handle to yesButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.asText,'Visible','on');
set(handles.fileText,'Visible','on');
set(handles.aviText,'Visible','on');
% Hint: get(hObject,'Value') returns toggle state of yesButton


% --- Executes on button press in noButton.
function noButton_Callback(hObject, eventdata, handles)
% hObject    handle to noButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.asText,'Visible','off');
set(handles.fileText,'Visible','off');
set(handles.aviText,'Visible','off');
% Hint: get(hObject,'Value') returns toggle state of noButton
