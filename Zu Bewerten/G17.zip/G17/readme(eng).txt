Prepare:
You should download the dataset from original files. Do not from cropped face images. 
The program supports P1E scene. If you choose another scene, please change the file name the same as P1E

Method.1

Change info in config.m:
1.Provide a source path.
  src =('*yourfilepath');
  
2.Select the left and right camera.
  L can be 1 or 2
  R can be 2 or 3
  (L&R can not be equal!)

3. Select start frame or use the given randi function (default is 0).

4. Choose the number of succeeding frames (default is 1).
   
5 Add background file path .
  Note: if bg is a picture, use bg=imread('bg_image.jpg');
        if bg is a video, use bg=VideoReader('bg_video.mp4');
 
  Default bg and render_mode are picture and 'substitute'. If you want to use a video file as bg, change render_mode to 'video' and provide a video file path.       

Then run the challenge.m. 


Method.2

1. Run the start_gui.m in the MATLAB Command Window.

2. Add the above parameters through the interactive buttons and boxes. （add path and must select background in order to correctly run the programm)

3. Toggle the 'Save' toggle button and provide a file name for the video file, if necessary.

4. If you want to start, click 'Start' button. 

5. If you want to stop, click 'Stop' button. (During this time you can change the parameters).
  

