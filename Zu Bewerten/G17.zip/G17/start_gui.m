%% Start GUI programmatically.
%% GUI .m file must be in the same folder as this script!
GUI();

