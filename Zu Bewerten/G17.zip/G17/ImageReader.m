classdef ImageReader< handle
%% Constructor variables  
    properties 
        src;
        L;
        R;
        start;
        N;
    end

    methods 
%%  test the validity of parameters        
        function ir = ImageReader(src, L, R, varargin)
            if L == 1 || L == 2 %left camera can be 1 and 2 
                ir.L = L;
            else
                error('L value must be either 1 or 2!') 
            end
            if R == 2 || R == 3 %right camera can only be 2 and 3
                ir.R = R;                
            else
                error('R value must be either 2 or 3!')
            end
            if ir.L == ir.R  % left and right camera can not equal
                error('Left camera must not equal right camera!')
            end
            ip = inputParser; %use inputParser to determine inputs and save them in class object.
            addRequired(ip,'src'); 
            addRequired(ip,'L',@(x)isnumeric(x)&&(x==1)||(x==2));
            addRequired(ip,'R',@(x)isnumeric(x)&&((x==2)||(x==3))&&(x~=L));
            addOptional(ip,'start',0,@(x)isnumeric(x)&&(x>=0));
            addOptional(ip,'N',1,@(x)isnumeric(x)&&(x>=0));
            parse(ip, src, L, R,varargin{:});
            ir.src=ip.Results.src;
            ir.L=ip.Results.L;
            ir.R=ip.Results.R;
            ir.start=ip.Results.start;
            ir.N=ip.Results.N;
        end
%% return left, right tensors and loop
        function [ left,right,loop] = next(ir) 
                
            if isunix % test computer system, here for unix system(Linux and mac)
                all_folder = strsplit(ir.src,'/'); 
                scene_folder = char(all_folder(end)); 
                srcL = fullfile(ir.src,[scene_folder,'_','C',num2str(ir.L),'/']);
                srcR = fullfile(ir.src,[scene_folder,'_','C',num2str(ir.R),'/']);
             
            else % test computer system, here for windows system
                all_folder = strsplit(ir.src,'\'); 
                scene_folder = char(all_folder(end));
                srcL = fullfile(ir.src,[scene_folder,'_','C',num2str(ir.L),'\']);
                srcR = fullfile(ir.src,[scene_folder,'_','C',num2str(ir.R),'\']);
            end
            srcR_list = dir(strcat(srcR,'*.jpg')); 
            srcL_list = dir(strcat(srcL,'*.jpg'));
            nR = length(srcR_list); %return the number of images, which we downloaded for left camera
            if ir.start>nR  %test the start value  
                error('start must smaller than the length of the image set')
            end
            begin=ir.start+1; % start value can be zero in the task, but the index of matlab must be 1
            numofimage=ir.N;  % return N
            left=zeros(600,800,(ir.N+1)); % initialize left tensor
            right=zeros(600,800,(ir.N+1));% initialize right tensor
            if nR-begin>=ir.N % test if we have enough images to take out from the defined start value
                index=0; 
                for i=begin:begin+numofimage
                    index=index+1;
                    image_name_l=srcL_list(i).name; %return image name
                    image_name_r=srcR_list(i).name;
                    current_image_l = imread(strcat(srcL,image_name_l)); %read the current image
                    current_image_r = imread(strcat(srcR,image_name_r));
                    left(:,:,(1+3*(index-1)):(3+3*(index-1)))=current_image_l;
                    right(:,:,(1+3*(index-1)):(3+3*(index-1)))=current_image_r;
                    %strl=['left cam:','Nr',num2str(i-1),'download image:',string( image_name_l)];
                    %disp(strl)
                    %strr=['right cam:','Nr',num2str(i-1),'download image:',string( image_name_r)];
                    %disp(strr)
                end
                    loop=0;
                    ir.start=ir.start+1; 
            else % if we do not have enough image to continiue to read.
               index=0;
               for j=begin:nR 
                    index=index+1;
                    image_name_l=srcL_list(j).name;
                    image_name_r=srcR_list(j).name;
                    current_image_l = imread(strcat(srcL,image_name_l));
                    current_image_r = imread(strcat(srcR,image_name_r));
                    left(:,:,(1+3*(index-1)):(3+3*(index-1)))=current_image_l;
                    right(:,:,(1+3*(index-1)):(3+3*(index-1)))=current_image_r;
                    %strl=['left cam:','Nr',num2str(j),'download image:',string( image_name_l)];
                    %disp(strl)
                    %strr=['right cam:','Nr',num2str(j),'download image:',string( image_name_r)];
                    %disp(strr)
                end
               loop=1; 
               ir.start=0;
           end
        end
   end
end
