function [results] = render(choose_frame,mask,bg,mode)
% Mask from segmentation part: the value for background is zero and the 
% value for foreground is one. 
% Modi means: change the value of background to one and the value 
% of foreground to zero. 
modi=mask-1;
modi(modi>=0)=0;
modi(modi<0)=1;
persistent a %special for reading each substitute video frame
         if isempty(a)
              a = 1; 
         end
% Multiple one (foreground) with the current image frame to get the
% original image of person. special case for 'foreground'
man=mask.*choose_frame;
switch mode
    case 'foreground'
        results=uint8(man); % return original foreground and black background
        imshow(results(:,:,1:3));
         
    case 'background'
        results=modi.*choose_frame; % return original background and black foreground 
        results=uint8(results);
        imshow(results(:,:,1:3));
         
    case 'substitute'
        bg = imresize(bg, [600, 800]); % change the size of the selected background picture
        double_bg=im2double(bg);
        results=modi.*double_bg; % return the background with the selected picture and the black foreground
        results=im2uint8(results); 
        man=uint8(man); %return the original foreground and the black background (value 0) 
        results=results+man; % add man and results together 
        imshow(results(:,:,1:3));
         
    case 'overlay'
        result1=man; %return the original foreground and the black background (value 0) 
        result1(:,:,2:3)=0;% change the 2nd and 3rd channe of current image 
        result2=modi.*choose_frame; 
        result2(:,:,3)=1;
        result2=uint8(result2);
        results=imadd(uint8(result1)*0.7,result2); % overlay two current parts 
        imshow(results(:,:,1:3));
    case 'video'
        video_pic = read(bg,a); % read the a-th frame of the substitute video.
        video_pic = imresize(video_pic, [600, 800]); %change the size of video frame
        video_pic =im2double(video_pic);
        results=modi.*video_pic;
        results=im2uint8(results);
        man=uint8(man);
        results=results(:,:,1:3)+man(:,:,1:3);
        imshow(results(:,:,1:3));
        a=a+1;
        if a > (bg.NumFrames)
             a = 1;
        end 
        
end
end
