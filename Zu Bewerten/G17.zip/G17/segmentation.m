function [mask,choose_frame] = segmentation(left, right)

  % This function create a Binary Mask.
  % Mask pixel values of 1 indicate the image pixel belongs to the Foreground. 
  % Mask pixel values of 0 indicate the image pixel is part of the background.

    %use the left camera
    [m,n,x] = size(left);
    x=x/3;  %x= N+1
    aver_frame=zeros(m,n,3);
%     if x<=2
%         aver_frame=left(:,:,1:3); %if N=1 just second frame -first frame
%     else
        for i=1:x
            aver_frame= aver_frame + left(:,:,1+3*(i-1):3+3*(i-1));
        end
        aver_frame=aver_frame/x; %find the average frame
%     end
    
    choose=ceil((x+1)/2);%find the middle frame
    choose_frame=left(:,:,1+3*(choose-1):3+3*(choose-1));
    sub=abs(aver_frame-choose_frame); %framesub
    
    sub(sub<13)=0; %set threshold
    
    mask = medfilt2(imbinarize(rgb2gray(sub))); %use the medfilt to move the noise
    mask = medfilt2(mask);
    mask = edge(mask,'canny',0.7);
    [c,r]=find(mask);
    k=boundary(c,r,0.2);
    c1=c(k);% col
    r1=r(k);% row
    R=r1';
    C=c1';
    mask=roipoly(mask,R,C); %use col and row point to build a ROI region --this is the outline of mask

end
