%% Computer Vision Challenge 2020 challenge.m

%% Start timer here

config

%% Generate Movie

loop=0;

while loop ~= 1
  % Get next image tensors
  [left,right,loop]=ir.next();
  % Generate binary mask
  [mask,choose_frame] =segmentation(left, right);
  % Render new frame
  % five types: 'foreground', 'background', 'substitute','overlay', 'video'. use video to replace picture background (Bonus).
  [results] = render( choose_frame,mask,bg,render_mode); 
  
  % Write Movie to Disk
if store
  v=VideoWriter(dest);     %Create avi video object，it is empty at the beginning
  v.FrameRate=30;          %define the frameramte of the video
  open(v);                 %Open file for writing video data
  writeVideo(v,results);   %write the video step by step
end
end

%% Stop timer here
elapsed_time = 0;