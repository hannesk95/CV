Anwendung:
MATLAB Editor
1.Für die Ausführung in der standardmäßigen MATLAB-Umgebung, stellen Sie sicher, dass es sich beim aktuellen 
MATLAB-Verzeichnis um das richtige Verzeichnis mit der Software handelt, und geben Sie in das Command Window 
folgenden Befehl ein:
>> challenge;

2.Sollten Sie einige Parameter zur Segmentierung anpassen wollen, so können Sie dies in der Datei config.m tun. 
Anbei eine kurze Erklärung zu den Parametern:

src           Dateipfad der Kamerabilder. Wählen Sie bitte den übergeordneten Pfad, zum Beispiel:
              C:\Users\Dell\Documents\Uni\SS2020\CV\Challenge\Videos\P1E_S1.
L             Nummer der linken Kamera {1; 2}.
R             Nummer der rechten Kamera {2; 3}.
start         Der Frame des Videos, ab dem die Segmentierung starten soll. Ganze Zahlen.
N             Anzahl der aufeinanderfolgenden Frames, die für die Segmentierung herangezogen werden sollen. Ganze Zahlen.
dest          Dateiname für das gerenderte Video.Denken Sie daran, die Dateierweiterung zu schreiben.
              (z.B. 'output.avi')
bg            Dateipfad des gewünschten Hintergrundbildes.
render_mode   Der gewünschte Rendering-Modus für das bearbeitete Video.
              {‚foreground‘, ‚background‘, ‚overlay‘, ‚substitute‘, ‚video‘}.
store         Soll das Video gespeichert werden? {true, false}.

3.Nachdem die Parameter in config korrekt eingestellt wurden, können Sie die Datei Challenge.m ausführen.

GUI
1.Starten Sie die GUI über das MATLAB Command Window.
>> start_gui;

2.Wählen Sie als erstes den gewünschten Dateipfad über die Schaltfläche.
Wichtig ist, dass Sie dabei nur den Ordner, nicht die einzelnen Bilddateien, auswählen!

3.Wählen Sie anschließend das gewünschte Hintergrundbild bzw. -video. Sie können die Dateiformate PNG, JPG, TIFF und MP4 verwenden. 
Das Laden eines Videos kann ein paar Sekunden in Anspruch nehmen. 
WICHTIG: Sie müssen eine Hintergrunddatei auswählen! Das Programm funktioniert nur, wenn eine zulässige Datei 
für den Hintergrund gewählt wurde!

4.Nun können Sie die Parameter des Renderings festlegen:
Wählen Sie die gewünschten Kameras, den Start-Frame sowie die Anzahl der Frames, die für die Verarbeitung 
herangezogen werden. Den Rendering-Modus können Sie über das Dropdown-Menü festlegen.Anschließend können Sie 
noch wählen, ob Sie das fertige Video speichern wollen. Sollten Sie „Ja“ anwählen, so können Sie noch den Dateinamen
 bestimmen.Ganz unten befindet sich die Videosteuerung. Sie können das Video starten, stoppen, und als Schleife 
abspielen („Loop“). Beachten Sie hierfür die Checkbox neben dem Loop-Button.


  