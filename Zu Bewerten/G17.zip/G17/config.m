%% Computer Vision Challenge 2020 config.m

%% Generall Settings
disp('Group number: 17')
disp('Group members: Ying Gu, Xiaoxuan Cai, Hongfei Yan, Ziwei Cheng, Georg Grichtmaier')
disp('mail: ying.gu@tum.de, xiaoxuan.cai@tum.de, ga92cas@mytum.de, ziwei.cheng@tum.de, ga87kim@mytum.de ')

group_number = 17;
members = {'Ying Gu', 'Xiaoxuan Cai','Hongfei Yan','Ziwei Cheng','Georg Grichtmaier'};
mail = {'ying.gu@tum.de','xiaoxuan.cai@tum.de' ,'ga92cas@mytum.de','ziwei.cheng@tum.de','ga87kim@mytum.de '};


%% Setup Image Reader
% Specify Scene Folder
src =('/Users/yanhongfei/Downloads/P1E_S1');
% Select Cameras
L = 1;
R = 2;
% Choose a start point
start = randi(1000);
% Choose the number of succseeding frames
N =4; 
ir = ImageReader(src, L, R, 'start',start,'N', N);

%% Output Settings
% Output Path
dest = "output.avi";
% Load Virual Background
% if you want to substitute background with picture, change here the following picture path
%bg=imread('bg_image.jpg');
% if you want to substitute background with video, change the following video path 
bg=VideoReader('bg_video.mp4'); 
% Select rendering mode
render_mode = 'video';
% Create a movie array
% movie =
% Store Output?
store = true;
