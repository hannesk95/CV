Readme

I. INTRODUCTION
    The MATLAB(R) program contained within this directory implements the background
    detection and replacement.
    This file describes the setup/installation proceedures for the code. 

II. Toolbox Requirements
    Following toolboxes must be installed at Matlab 2020a:
	1. Image Processing Toolbox
	2. Partial Differential Equation Toolbox

III. CONTENTS
    In the G22/ directory, you should find the following files:
        ImageReader.m
        segmentation.m
	render.m
        challenge.m
        config.m
	start_gui.m
        <PathToYourBgVideo>.mp4
	<PathToYourBgImage>.png
	<PathToYourOutputDIR>.avi
        Dataset/**
	**Path to the directory with Choke Dataset

IV. SETUP/INSTALLATION for GUI
    1. You must have MATLAB 2020a software and the toolboxes installed on your computer
    2. Copy/move the 'G22' folder to the MATLAB 'work' directory
    3. Open Matlab in the directory 'G22'
    4. To run, open the 'start_gui.m' file and press F5 or use the
        command line: >> start_gui
    5. Now the GUI is open and now proceed the following 
        a. Select a 'Mode' for Image or Video as a background
        b. Select a path for stereo input at 'Scene'
        c. Select a background file at 'Background'
        d. Select a folder with 'Save as' in which rendered left images will be stored to
	e. Select a Value for 'L' and 'R'
        f. Select a render mode at 'Render Mode'
	g. Select a video mode at 'Video Mode'
	h. Select a starting frame number at 'Starting Frame'
	i. Click on 'Start' to start the process
	j. One can change the 'Render Mode', 'Video Mode' and 'Starting Frame' at any time
	k. If you want to stop the program, you can click on the 'Stop' button 
	l. If you want to reset the program, you can click on the 'Reset Settings' button 


V. SETUP/INSTALLATION for challenge.m/config.m
    1. You must have MATLAB 2020a software and the toolboxes installed on your computer
    2. Copy/move the 'G22' folder to the MATLAB 'work' directory
    3. Open Matlab in the directory 'G22'
    4. Before starting the challenge.m, some settings must be made at config.m
	a. Write a path for stereo input at 'src'
	b. Select the number for the left ('L') and right ('R') camera
	c. Select a starting frame number with 'start' (optional)
	d. The value for N should stay at 8 for an optimal result!
	e. Select the paths for 'bgPath', 'storePath', 'videoPath' or use the preset settings
	f. Select a 'render_mode' or use the preset settings
    5. To run, open the 'challenge.m' file and press F5 or use the 
	command line: >> challenge


