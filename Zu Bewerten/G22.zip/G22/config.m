%% Computer Vision Challenge 2020 config.m

%% Generall Settings
% Group number: 
group_number = 22;
 
% Group members:
members = {'Yasin Ciritci', 'Ismail Kuzu', 'Utku Ayvaz', 'Ali Simsek', 'Eren Tamtekin'};


% Email-Address (from Moodle!):
mail = {'yasin.ciritci@tum.de', 'i.kuzu@tum.de', 'utku.ayvaz@tum.de', 'ali.simsek@tum.de', 'eren.tamtekin@tum.de'};


%% Setup Image Reader
% Specify Scene Folder
src = "../../Dataset/P1E_S1";

% Select Cameras
L = 1;
R = 2;

% Choose a start point
start = 200;

% Choose the number of succseeding frames
N = 8; % This value should remain as it delivers the optimal results!!!

ir = ImageReader(src, L, R, start, N);
loop = 0;

%% Output Settings
% Output Path
dest = "output.avi";

% Load Virual Background
bgPath = 'bg.png';
bg = imresize(imread(bgPath), ir.dimens(1:2));

% Select rendering mode
render_mode = "substitute";

% Create a movie array
storePath = "output";
videoPath = "Agua-natural.mp4"; % Path to virtual Background (video)
if ~exist(storePath, 'dir')
    mkdir(storePath)
end

% Store Output?
store = true;
