function [result] = render(frame,mask,bg,render_mode)
%render - Applies a certain mode/background to the frame with the help
% of the mask.
% Depending on the chosen input from the user the mode will be applied.
%
% Syntax:  [result] = render(frame,mask,bg,mode)
%
% Inputs:
%    frame - Current displayed frame as a rgb image
%    mask  - Segmentation mask as a logical matrix with image dimenions
%    bg    - Selected background frame from an image or a video
%    mode  - Selected mode from the user: 
%            foreground - Sets the background to black. Foreground in the
%                         image remains the same.  
%            background - Sets the foreground to black. Background in the 
%                         image remains the same.
%               overlay - Foreground and background are displayed with
%                         distinguishable colours
%            substitute - Replaces the background with a virtual background
%                         which is chosen by bg.

% Outputs:
%    result - Modified frame with selected mode.
%             
%
% Other m-files required: none
% Subfunctions: overlay
% MAT-files required: none
%
% See also: challenge,  image_reader, segmentation
% Author: Group 22
% email:
% July 2020; Last revision: 07-July-2020
  switch render_mode
      case 'foreground'
          result = bsxfun(@times, frame, cast(mask, class(frame)));
      case 'background'
          result = bsxfun(@times, frame, cast(~mask, class(frame)));
      case 'overlay' 
          result = overlay(frame, mask, [66,0,99], [255,94,19]);
      case 'substitute'
          result = bsxfun(@times, frame, cast(mask, class(frame))) + ...
              bsxfun(@times, bg, cast(~mask, class(bg)));
  end

end

function overlayedImg = overlay(frame, mask, fgColor, bgColor)
%overlay - Overlay mode for function render
% 
% Depending on the chosen input from the user the mode will be applied.
%
% Syntax:  [result] = render(frame,mask,bg,mode)
%
% Inputs:
%    frame   - Current displayed frame as a RGB image
%    mask    - Segmentation mask as a logical matrix with image dimenions
%    fgColor - RGB array for foreground coloring 
%    bgColor - RGB array for background coloring

% Outputs:
%    overlayedImg - Modified frame with overlay mode.

   maskedFrame = uint8(logical(bsxfun(@times, frame, cast(mask, class(frame)))));
   [width, height, ~] = size(maskedFrame);
   frameFG = reshape(reshape(maskedFrame, width*height,3) .* uint8(fgColor), width, height, 3);
   frameBG = reshape(reshape(1 - maskedFrame, width*height,3) .* uint8(bgColor), width, height, 3);
   overlayedImg = frameFG + frameBG;
end
