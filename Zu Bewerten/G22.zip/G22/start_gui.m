classdef start_gui < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                     matlab.ui.Figure
        GridLayout                   matlab.ui.container.GridLayout
        LeftPanel                    matlab.ui.container.Panel
        SceneButton                  matlab.ui.control.Button
        BackgroundButton             matlab.ui.control.Button
        RendermodeDropDown           matlab.ui.control.DropDown
        SettingsLabel                matlab.ui.control.Label
        LabelBG                      matlab.ui.control.Label
        pathBg                       matlab.ui.control.EditField
        EditField                    matlab.ui.control.EditField
        SaveasButton                 matlab.ui.control.Button
        savePath                     matlab.ui.control.EditField
        RenderModeButton             matlab.ui.control.Button
        VideoModeButton              matlab.ui.control.Button
        StartingFrameButton          matlab.ui.control.Button
        StartPoint                   matlab.ui.control.Spinner
        VideomodeDropDown            matlab.ui.control.DropDown
        ModeSwitch                   matlab.ui.control.Switch
        ModeButton                   matlab.ui.control.Button
        LeftCamDropDown              matlab.ui.control.DropDown
        LeftCameraButton             matlab.ui.control.Button
        RightCamDropDown             matlab.ui.control.DropDown
        RightCameraButton            matlab.ui.control.Button
        CenterPanel                  matlab.ui.container.Panel
        GridLayout2                  matlab.ui.container.GridLayout
        RightPanel                   matlab.ui.container.Panel
        UIAxesInBg                   matlab.ui.control.UIAxes
        UIAxesOuBg                   matlab.ui.control.UIAxes
        StopButton_2                 matlab.ui.control.Button
        ResetSettingsButton          matlab.ui.control.Button
        StartButton                  matlab.ui.control.Button
        ContextMenu                  matlab.ui.container.ContextMenu
        SelectafilepathforsceneMenu  matlab.ui.container.Menu
        ContextMenu2                 matlab.ui.container.ContextMenu
        SelectfilepathforabackgroundimageorabackgroundvideoMenu  matlab.ui.container.Menu
        ContextMenu3                 matlab.ui.container.ContextMenu
        ChooseafilepathforsavingtherenderedmovietoanyfilepathMenu  matlab.ui.container.Menu
        ContextMenu4                 matlab.ui.container.ContextMenu
        Menu                         matlab.ui.container.Menu
        ForgroundMenu                matlab.ui.container.Menu
        BackgroundMenu               matlab.ui.container.Menu
        OverlayMenu                  matlab.ui.container.Menu
        SubstituteMenu               matlab.ui.container.Menu
        ContextMenu5                 matlab.ui.container.ContextMenu
        LoopProcesswillbeginnagainafteronetakeMenu  matlab.ui.container.Menu
        DefaultItwillonlyberenderedonceMenu  matlab.ui.container.Menu
        ContextMenu6                 matlab.ui.container.ContextMenu
        Menu_2                       matlab.ui.container.Menu
    end

    % Properties that correspond to apps with auto-reflow
    properties (Access = private)
        onePanelWidth = 576;
        twoPanelWidth = 768;
    end

    
    properties (Access = public)
        UIAxes    matlab.ui.control.UIAxes % Description
        path
        loop
        stop
        loop1
    end
    
    methods (Access = public)
        
        function setOn(app)
            set(app.ModeSwitch,'Enable','off');
            set(app.ModeButton,'Enable','off');
            set(app.ModeSwitch,'Enable','off');
            set(app.SceneButton,'Enable','off');
            set(app.BackgroundButton,'Enable','off');
            set(app.SaveasButton,'Enable','off');
            set(app.savePath,'Enable','off');
            set(app.pathBg,'Enable','off');
            set(app.EditField,'Enable','off');
            set(app.LeftCamDropDown,'Enable','off');
            set(app.RightCamDropDown,'Enable','off')
            set(app.LeftCameraButton,'Enable','off')
            set(app.RightCameraButton,'Enable','off')
        end
    end

    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: SceneButton
        function SceneButtonPushed(app, event)
            % Get the name of the file that the user wants to use.
            app.path.fl = uigetdir('/');
            if app.path.fl == 0
                % User clicked the Cancel button.
                drawnow;
                figure(app.UIFigure)
                return;
            else
                app.EditField.Value = app.path.fl;
            end
            drawnow;
            figure(app.UIFigure)
        end

        % Button pushed function: BackgroundButton
        function BackgroundButtonPushed(app, event)
            if strcmp(app.ModeSwitch.Value,'Image')
                startingFolder = '/';
                if ~exist(startingFolder, 'dir')
                    % If that folder doesn't exist, just start in the current folder.
                    startingFolder = pwd;
                end
                % Get the name of the file that the user wants to use.
                [baseFileName, folder] = uigetfile({'*.png';'*.jpg';'*.jpeg'}, 'Select a file');
                if baseFileName == 0
                    % User clicked the Cancel button.
                    drawnow;
                    figure(app.UIFigure)
                    return;
                end
                fullFileName = fullfile(folder, baseFileName);
                
                
                app.path.bg = imread(fullFileName);
                
            elseif strcmp(app.ModeSwitch.Value,'Video')
                startingFolder = '/';
                if ~exist(startingFolder, 'dir')
                    % If that folder doesn't exist, just start in the current folder.
                    startingFolder = pwd;
                end
                % Get the name of the file that the user wants to use.
                [baseFileName, folder] = uigetfile({'*.mp4';'*.avi'}, 'Select a file');
                if baseFileName == 0
                    % User clicked the Cancel button.
                    drawnow;
                    figure(app.UIFigure)
                    return;
                end
                fullFileName = fullfile(folder, baseFileName);
            end
            
            app.pathBg.Value = fullFileName;
            drawnow;
            figure(app.UIFigure)
        end

        % Button pushed function: SaveasButton
        function SaveasButtonPushed(app, event)
            startingSave = '/';
            if ~exist(startingSave, 'dir')
                % If that folder doesn't exist, just start in the current folder.
                startingSave = pwd;
            end
            % Get the name of the file that the user wants to use.
            app.path.outPut = uigetdir('/');
            %app.savePath.Value = app.path.outPut;
            if app.path.outPut == 0
                % User clicked the Cancel button.
                drawnow;
                figure(app.UIFigure)
                return;
            else
            app.savePath.Value = app.path.outPut;
            app.path.storePath = app.path.outPut;
            app.path.frNbr=1;
            end
            drawnow;
            figure(app.UIFigure)
            
        end

        % Callback function
        function ImageClicked(app, event)
            imshow(myImage)
        end

        % Button pushed function: StartButton
        function StartButtonPushed(app, event)
           
            if isempty(app.EditField.Value)
                fig = app.UIFigure;
                uialert(fig,'Please select a path file for the stereoinput. The choosen path file should e.g. be like /../Checkpoint/P1E_S1','Error in Settings');
                drawnow();
                return
            end
            if isempty(app.pathBg.Value)
                fig = app.UIFigure;
                uialert(fig,'Please select a image or video for the background.','Error in Settings');
                drawnow();
                return
            end
            if isempty(app.StartPoint.Value)
                app.StartPoint.Value = 1;
                %app.path.frameNbr = app.StartPoint.Value;
            end
            if app.StartPoint.Value <= 0
                fig = app.UIFigure;
                uialert(fig,'The starting point (frame number) should be greater than 0. E.g. 1. Please do not exceed the size of the scene file.','Error in Settings');
                drawnow();
                return
            end
            L = str2double(app.LeftCamDropDown.Value);
            R = str2double(app.RightCamDropDown.Value);
            ir = ImageReader(app.path.fl,L,R,app.StartPoint.Value,8);
            if ir.numImages-ir.N < ir.start
                fig = app.UIFigure;
                uialert(fig,'Starting Frame Number must be smaller, exceeds boundaries. Please check file number in Scene path.','Error in Settings');
                drawnow();
                return
            end
            
            app.setOn();
            if strcmp(app.ModeSwitch.Value,'Video')
                videoPath = app.pathBg.Value;
                v = VideoReader(videoPath);
            end
            %%
            app.loop = 0;
            app.loop1 = 0;
            drawnow();
            
            while (app.loop ~= 1 && app.loop1 ~=1)
               % Get next image tensors
              app.loop = ir.next();
              if strcmp(app.ModeSwitch.Value,'Video')
                  if hasFrame(v)
                      app.path.bg = imresize(readFrame(v), ir.dimens(1:2));
                  else 
                      v = VideoReader(videoPath);
                      app.path.bg = imresize(readFrame(v), ir.dimens(1:2));
                  end
              else
                  app.path.bg = imresize(imread(app.pathBg.Value), ir.dimens(1:2));
              end
                         
              % Generate binary mask
              [mask] = segmentation(ir.left,ir.right);
              % Render new frame
              renderableImg = ir.left{ceil((end + 1)/2)};
              result = render(renderableImg, mask, app.path.bg, app.RendermodeDropDown.Value);
             
              imwrite(result, fullfile(app.path.storePath, ir.leftImageFiles(min(ir.start + ir.N/2,ir.numImages)).name));
              imshow(ir.left{ir.N/2 +1},'Parent',app.UIAxesInBg)  
              imshow(result,'Parent',app.UIAxesOuBg)
       
              pause(1/1000);
              
             if ir.N+ir.start>ir.numImages  && strcmp(app.VideomodeDropDown.Value, 'Loop') 
                ir = ImageReader(app.path.fl,1,3,app.StartPoint.Value,8);
                app.loop = 0;
              
             elseif ir.N+ir.start>ir.numImages && strcmp(app.VideomodeDropDown.Value, 'Default')
                 app.loop = 1;
             else
                ir.start = ir.start+1;
                app.loop = 0;
             end
           drawnow(); 
            end
    dest = 'output.avi';    
    v = VideoWriter(dest,'Motion JPEG AVI');
    jpgs = dir(fullfile(app.path.storePath, '*.jpg'));
    open(v);
    for i=1:size(jpgs,1)
      I = imread(fullfile(jpgs(i).folder,jpgs(i).name)); %read the next image
      writeVideo(v,I); %write the image to file
    end
    close(v);
        end

        % Value changed function: StartPoint
        function StartPointValueChanged(app, event)
            %app.path.frameNbr = app.StartPoint.Value;
            
        end

        % Callback function
        function StopButtonPushed(app, event)
            
        end

        % Button pushed function: ResetSettingsButton
        function ResetSettingsButtonPushed(app, event)
            % Make current instance of app invisible
            app.UIFigure.Visible = 'off';
            % Open 2nd instance of app
            start_gui();
            % Delete old instance
            close(app.UIFigure)
        end

        % Button pushed function: StopButton_2
        function StopButton_2Pushed(app, event)
            app.loop1 = 1;
            app.loop = 1;
            set(app.ModeSwitch,'Enable','on');
            set(app.ModeButton,'Enable','on');
            set(app.ModeSwitch,'Enable','on');
            set(app.SceneButton,'Enable','on');
            set(app.BackgroundButton,'Enable','on');
            set(app.SaveasButton,'Enable','on');
            set(app.savePath,'Enable','on');
            set(app.pathBg,'Enable','on');
            set(app.EditField,'Enable','on');
            set(app.LeftCamDropDown,'Enable','on');
            set(app.RightCamDropDown,'Enable','on')
            set(app.LeftCameraButton,'Enable','on')
            set(app.RightCameraButton,'Enable','on')
            drawnow();
        end

        % Value changed function: ModeSwitch
        function ModeSwitchValueChanged(app, event)
            %value = app.ModeSwitch.Value;
            app.pathBg.Value = '';
            app.LabelBG.Text = '';
            app.path.bg = '';
            drawnow();
        end

        % Changes arrangement of the app based on UIFigure width
        function updateAppLayout(app, event)
            currentFigureWidth = app.UIFigure.Position(3);
            if(currentFigureWidth <= app.onePanelWidth)
                % Change to a 3x1 grid
                app.GridLayout.RowHeight = {348, 348, 348};
                app.GridLayout.ColumnWidth = {'1x'};
                app.CenterPanel.Layout.Row = 1;
                app.CenterPanel.Layout.Column = 1;
                app.LeftPanel.Layout.Row = 2;
                app.LeftPanel.Layout.Column = 1;
                app.RightPanel.Layout.Row = 3;
                app.RightPanel.Layout.Column = 1;
            elseif (currentFigureWidth > app.onePanelWidth && currentFigureWidth <= app.twoPanelWidth)
                % Change to a 2x2 grid
                app.GridLayout.RowHeight = {348, 348};
                app.GridLayout.ColumnWidth = {'1x', '1x'};
                app.CenterPanel.Layout.Row = 1;
                app.CenterPanel.Layout.Column = [1,2];
                app.LeftPanel.Layout.Row = 2;
                app.LeftPanel.Layout.Column = 1;
                app.RightPanel.Layout.Row = 2;
                app.RightPanel.Layout.Column = 2;
            else
                % Change to a 1x3 grid
                app.GridLayout.RowHeight = {'1x'};
                app.GridLayout.ColumnWidth = {295, '1x', 751};
                app.LeftPanel.Layout.Row = 1;
                app.LeftPanel.Layout.Column = 1;
                app.CenterPanel.Layout.Row = 1;
                app.CenterPanel.Layout.Column = 2;
                app.RightPanel.Layout.Row = 1;
                app.RightPanel.Layout.Column = 3;
            end
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.AutoResizeChildren = 'off';
            app.UIFigure.Color = [1 1 1];
            app.UIFigure.Position = [100 100 1058 348];
            app.UIFigure.Name = 'CV Project - Group 22';
            app.UIFigure.Resize = 'off';
            app.UIFigure.SizeChangedFcn = createCallbackFcn(app, @updateAppLayout, true);

            % Create GridLayout
            app.GridLayout = uigridlayout(app.UIFigure);
            app.GridLayout.ColumnWidth = {295, '1x', 751};
            app.GridLayout.RowHeight = {'1x'};
            app.GridLayout.ColumnSpacing = 0;
            app.GridLayout.RowSpacing = 0;
            app.GridLayout.Padding = [0 0 0 0];
            app.GridLayout.Scrollable = 'on';

            % Create LeftPanel
            app.LeftPanel = uipanel(app.GridLayout);
            app.LeftPanel.BackgroundColor = [0.7608 0.8588 0.8784];
            app.LeftPanel.Layout.Row = 1;
            app.LeftPanel.Layout.Column = 1;

            % Create SceneButton
            app.SceneButton = uibutton(app.LeftPanel, 'push');
            app.SceneButton.ButtonPushedFcn = createCallbackFcn(app, @SceneButtonPushed, true);
            app.SceneButton.BackgroundColor = [0.8784 0.9412 0.949];
            app.SceneButton.Position = [7 257 91 22];
            app.SceneButton.Text = 'Scene';

            % Create BackgroundButton
            app.BackgroundButton = uibutton(app.LeftPanel, 'push');
            app.BackgroundButton.ButtonPushedFcn = createCallbackFcn(app, @BackgroundButtonPushed, true);
            app.BackgroundButton.BackgroundColor = [0.8784 0.9412 0.949];
            app.BackgroundButton.Position = [7 226 91 22];
            app.BackgroundButton.Text = 'Background';

            % Create RendermodeDropDown
            app.RendermodeDropDown = uidropdown(app.LeftPanel);
            app.RendermodeDropDown.Items = {'foreground', 'background', 'overlay', 'substitute'};
            app.RendermodeDropDown.BackgroundColor = [0.8784 0.9412 0.949];
            app.RendermodeDropDown.Position = [104 103 186 22];
            app.RendermodeDropDown.Value = 'foreground';

            % Create SettingsLabel
            app.SettingsLabel = uilabel(app.LeftPanel);
            app.SettingsLabel.BackgroundColor = [0.7608 0.8588 0.8784];
            app.SettingsLabel.FontWeight = 'bold';
            app.SettingsLabel.Position = [122 319 53 22];
            app.SettingsLabel.Text = 'Settings';

            % Create LabelBG
            app.LabelBG = uilabel(app.LeftPanel);
            app.LabelBG.Visible = 'off';
            app.LabelBG.Position = [9 14 271 22];
            app.LabelBG.Text = 'Background';

            % Create pathBg
            app.pathBg = uieditfield(app.LeftPanel, 'text');
            app.pathBg.BackgroundColor = [0.8784 0.9412 0.949];
            app.pathBg.Position = [104 226 186 22];

            % Create EditField
            app.EditField = uieditfield(app.LeftPanel, 'text');
            app.EditField.BackgroundColor = [0.8784 0.9412 0.949];
            app.EditField.Position = [104 257 186 22];

            % Create SaveasButton
            app.SaveasButton = uibutton(app.LeftPanel, 'push');
            app.SaveasButton.ButtonPushedFcn = createCallbackFcn(app, @SaveasButtonPushed, true);
            app.SaveasButton.BackgroundColor = [0.8784 0.9412 0.949];
            app.SaveasButton.Position = [7 195 91 22];
            app.SaveasButton.Text = 'Save as';

            % Create savePath
            app.savePath = uieditfield(app.LeftPanel, 'text');
            app.savePath.BackgroundColor = [0.8784 0.9412 0.949];
            app.savePath.Position = [104 195 186 22];

            % Create RenderModeButton
            app.RenderModeButton = uibutton(app.LeftPanel, 'push');
            app.RenderModeButton.BackgroundColor = [0.8784 0.9412 0.949];
            app.RenderModeButton.Position = [7 103 91 22];
            app.RenderModeButton.Text = 'Render Mode';

            % Create VideoModeButton
            app.VideoModeButton = uibutton(app.LeftPanel, 'push');
            app.VideoModeButton.BackgroundColor = [0.8784 0.9412 0.949];
            app.VideoModeButton.Position = [7 72 91 22];
            app.VideoModeButton.Text = 'Video Mode';

            % Create StartingFrameButton
            app.StartingFrameButton = uibutton(app.LeftPanel, 'push');
            app.StartingFrameButton.BackgroundColor = [0.8784 0.9412 0.949];
            app.StartingFrameButton.Position = [7 42 91 22];
            app.StartingFrameButton.Text = 'Starting Frame';

            % Create StartPoint
            app.StartPoint = uispinner(app.LeftPanel);
            app.StartPoint.Limits = [0 Inf];
            app.StartPoint.ValueChangedFcn = createCallbackFcn(app, @StartPointValueChanged, true);
            app.StartPoint.BackgroundColor = [0.8784 0.9412 0.949];
            app.StartPoint.Position = [105 42 185 22];

            % Create VideomodeDropDown
            app.VideomodeDropDown = uidropdown(app.LeftPanel);
            app.VideomodeDropDown.Items = {'Default', 'Loop'};
            app.VideomodeDropDown.BackgroundColor = [0.8784 0.9412 0.949];
            app.VideomodeDropDown.Position = [104 72 186 22];
            app.VideomodeDropDown.Value = 'Default';

            % Create ModeSwitch
            app.ModeSwitch = uiswitch(app.LeftPanel, 'slider');
            app.ModeSwitch.Items = {'Image', 'Video'};
            app.ModeSwitch.ValueChangedFcn = createCallbackFcn(app, @ModeSwitchValueChanged, true);
            app.ModeSwitch.Position = [150 289 45 20];
            app.ModeSwitch.Value = 'Image';

            % Create ModeButton
            app.ModeButton = uibutton(app.LeftPanel, 'push');
            app.ModeButton.BackgroundColor = [0.8784 0.9412 0.949];
            app.ModeButton.Position = [7 288 91 22];
            app.ModeButton.Text = ' Mode';

            % Create LeftCamDropDown
            app.LeftCamDropDown = uidropdown(app.LeftPanel);
            app.LeftCamDropDown.Items = {'1', '2'};
            app.LeftCamDropDown.BackgroundColor = [0.8784 0.9412 0.949];
            app.LeftCamDropDown.Position = [104 163 186 22];
            app.LeftCamDropDown.Value = '1';

            % Create LeftCameraButton
            app.LeftCameraButton = uibutton(app.LeftPanel, 'push');
            app.LeftCameraButton.BackgroundColor = [0.8784 0.9412 0.949];
            app.LeftCameraButton.Position = [7 163 91 22];
            app.LeftCameraButton.Text = 'Left Camera';

            % Create RightCamDropDown
            app.RightCamDropDown = uidropdown(app.LeftPanel);
            app.RightCamDropDown.Items = {'2', '3'};
            app.RightCamDropDown.BackgroundColor = [0.8784 0.9412 0.949];
            app.RightCamDropDown.Position = [105 133 186 22];
            app.RightCamDropDown.Value = '2';

            % Create RightCameraButton
            app.RightCameraButton = uibutton(app.LeftPanel, 'push');
            app.RightCameraButton.BackgroundColor = [0.8784 0.9412 0.949];
            app.RightCameraButton.Position = [7 133 91 22];
            app.RightCameraButton.Text = 'Right Camera';

            % Create CenterPanel
            app.CenterPanel = uipanel(app.GridLayout);
            app.CenterPanel.BackgroundColor = [0.3804 0.5294 0.6];
            app.CenterPanel.Layout.Row = 1;
            app.CenterPanel.Layout.Column = 2;

            % Create GridLayout2
            app.GridLayout2 = uigridlayout(app.CenterPanel);
            app.GridLayout2.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout2.HandleVisibility = 'off';

            % Create RightPanel
            app.RightPanel = uipanel(app.GridLayout);
            app.RightPanel.ForegroundColor = [1 1 1];
            app.RightPanel.BackgroundColor = [0.9412 0.9412 0.9412];
            app.RightPanel.Layout.Row = 1;
            app.RightPanel.Layout.Column = 3;

            % Create UIAxesInBg
            app.UIAxesInBg = uiaxes(app.RightPanel);
            title(app.UIAxesInBg, '')
            xlabel(app.UIAxesInBg, '')
            ylabel(app.UIAxesInBg, '')
            app.UIAxesInBg.AmbientLightColor = [0.7608 0.8588 0.8784];
            app.UIAxesInBg.ALim = [0 1];
            app.UIAxesInBg.ClippingStyle = 'rectangle';
            app.UIAxesInBg.Alphamap = [0.76 0.86 0.88];
            app.UIAxesInBg.GridColor = [0.7608 0.8588 0.8784];
            app.UIAxesInBg.MinorGridColor = [0.7608 0.8588 0.8784];
            app.UIAxesInBg.BoxStyle = 'full';
            app.UIAxesInBg.XTick = [];
            app.UIAxesInBg.YTick = [];
            app.UIAxesInBg.Color = [0.7608 0.8588 0.8784];
            app.UIAxesInBg.NextPlot = 'replace';
            app.UIAxesInBg.Visible = 'off';
            app.UIAxesInBg.BackgroundColor = [0.9412 0.9412 0.9412];
            app.UIAxesInBg.Clipping = 'off';
            app.UIAxesInBg.Position = [7 35 400 292];

            % Create UIAxesOuBg
            app.UIAxesOuBg = uiaxes(app.RightPanel);
            title(app.UIAxesOuBg, '')
            xlabel(app.UIAxesOuBg, '')
            ylabel(app.UIAxesOuBg, '')
            app.UIAxesOuBg.GridColor = [1 1 1];
            app.UIAxesOuBg.MinorGridColor = [1 1 1];
            app.UIAxesOuBg.XTick = [];
            app.UIAxesOuBg.YTick = [];
            app.UIAxesOuBg.Color = [0.7608 0.8588 0.8784];
            app.UIAxesOuBg.NextPlot = 'replace';
            app.UIAxesOuBg.Visible = 'off';
            app.UIAxesOuBg.BackgroundColor = [0.9412 0.9412 0.9412];
            app.UIAxesOuBg.Clipping = 'off';
            app.UIAxesOuBg.Position = [345 34 401 292];

            % Create StopButton_2
            app.StopButton_2 = uibutton(app.RightPanel, 'push');
            app.StopButton_2.ButtonPushedFcn = createCallbackFcn(app, @StopButton_2Pushed, true);
            app.StopButton_2.BackgroundColor = [0.7608 0.8588 0.8784];
            app.StopButton_2.Position = [330 14 91 29];
            app.StopButton_2.Text = 'Stop';

            % Create ResetSettingsButton
            app.ResetSettingsButton = uibutton(app.RightPanel, 'push');
            app.ResetSettingsButton.ButtonPushedFcn = createCallbackFcn(app, @ResetSettingsButtonPushed, true);
            app.ResetSettingsButton.BackgroundColor = [0.7608 0.8588 0.8784];
            app.ResetSettingsButton.Position = [441 14 91 29];
            app.ResetSettingsButton.Text = 'Reset Settings';

            % Create StartButton
            app.StartButton = uibutton(app.RightPanel, 'push');
            app.StartButton.ButtonPushedFcn = createCallbackFcn(app, @StartButtonPushed, true);
            app.StartButton.BackgroundColor = [0.7608 0.8588 0.8784];
            app.StartButton.Position = [214 14 90 29];
            app.StartButton.Text = 'Start';

            % Create ContextMenu
            app.ContextMenu = uicontextmenu(app.UIFigure);
            
            % Assign app.ContextMenu
            app.SceneButton.ContextMenu = app.ContextMenu;
            app.EditField.ContextMenu = app.ContextMenu;

            % Create SelectafilepathforsceneMenu
            app.SelectafilepathforsceneMenu = uimenu(app.ContextMenu);
            app.SelectafilepathforsceneMenu.Text = 'Select a file path to play and render the choosen scene. This choosen file should e.g. be like P1E_S1.';

            % Create ContextMenu2
            app.ContextMenu2 = uicontextmenu(app.UIFigure);
            
            % Assign app.ContextMenu2
            app.BackgroundButton.ContextMenu = app.ContextMenu2;
            app.pathBg.ContextMenu = app.ContextMenu2;

            % Create SelectfilepathforabackgroundimageorabackgroundvideoMenu
            app.SelectfilepathforabackgroundimageorabackgroundvideoMenu = uimenu(app.ContextMenu2);
            app.SelectfilepathforabackgroundimageorabackgroundvideoMenu.Text = 'Select file path for a background image or a background video.';

            % Create ContextMenu3
            app.ContextMenu3 = uicontextmenu(app.UIFigure);
            
            % Assign app.ContextMenu3
            app.SaveasButton.ContextMenu = app.ContextMenu3;
            app.savePath.ContextMenu = app.ContextMenu3;

            % Create ChooseafilepathforsavingtherenderedmovietoanyfilepathMenu
            app.ChooseafilepathforsavingtherenderedmovietoanyfilepathMenu = uimenu(app.ContextMenu3);
            app.ChooseafilepathforsavingtherenderedmovietoanyfilepathMenu.Text = 'Choose a file path for saving the rendered movie to any file path';

            % Create ContextMenu4
            app.ContextMenu4 = uicontextmenu(app.UIFigure);
            
            % Assign app.ContextMenu4
            app.RendermodeDropDown.ContextMenu = app.ContextMenu4;
            app.RenderModeButton.ContextMenu = app.ContextMenu4;
            app.VideomodeDropDown.ContextMenu = app.ContextMenu4;
            app.LeftCamDropDown.ContextMenu = app.ContextMenu4;
            app.LeftCameraButton.ContextMenu = app.ContextMenu4;
            app.RightCamDropDown.ContextMenu = app.ContextMenu4;
            app.RightCameraButton.ContextMenu = app.ContextMenu4;

            % Create Menu
            app.Menu = uimenu(app.ContextMenu4);
            app.Menu.Text = 'Choose a rendering mode for the function render.m. This will affect your outcome. ';

            % Create ForgroundMenu
            app.ForgroundMenu = uimenu(app.ContextMenu4);
            app.ForgroundMenu.Text = 'Forground:';

            % Create BackgroundMenu
            app.BackgroundMenu = uimenu(app.ContextMenu4);
            app.BackgroundMenu.Text = 'Background:';

            % Create OverlayMenu
            app.OverlayMenu = uimenu(app.ContextMenu4);
            app.OverlayMenu.Text = 'Overlay:';

            % Create SubstituteMenu
            app.SubstituteMenu = uimenu(app.ContextMenu4);
            app.SubstituteMenu.Text = 'Substitute:';

            % Create ContextMenu5
            app.ContextMenu5 = uicontextmenu(app.UIFigure);
            
            % Assign app.ContextMenu5
            app.VideoModeButton.ContextMenu = app.ContextMenu5;
            app.ModeButton.ContextMenu = app.ContextMenu5;

            % Create LoopProcesswillbeginnagainafteronetakeMenu
            app.LoopProcesswillbeginnagainafteronetakeMenu = uimenu(app.ContextMenu5);
            app.LoopProcesswillbeginnagainafteronetakeMenu.Text = 'Loop: Process will beginn again after one take.';

            % Create DefaultItwillonlyberenderedonceMenu
            app.DefaultItwillonlyberenderedonceMenu = uimenu(app.ContextMenu5);
            app.DefaultItwillonlyberenderedonceMenu.Text = 'Default: It will only be rendered once.';

            % Create ContextMenu6
            app.ContextMenu6 = uicontextmenu(app.UIFigure);
            
            % Assign app.ContextMenu6
            app.StartingFrameButton.ContextMenu = app.ContextMenu6;

            % Create Menu_2
            app.Menu_2 = uimenu(app.ContextMenu6);
            app.Menu_2.Text = 'Choose your starting frame/image number for rendering. The program will start rendering at yout choosen point. ';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = start_gui

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end