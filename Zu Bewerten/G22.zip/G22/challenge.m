%% Computer Vision Challenge 2020 challenge.m
config
v = VideoReader(videoPath);
%% Start timer here
tic
%% Generate Movie
while loop ~= 1
    % Get next image tensors
    [~,~,loop] = ir.next();
    if hasFrame(v)
        bg = imresize(readFrame(v), ir.dimens(1:2));
    else
        v = VideoReader(videoPath);
        bg = imresize(readFrame(v), ir.dimens(1:2));
    end
    % Generate binary mask
    [mask] = segmentation(ir.left,ir.right);
    % Render new frame
    renderableImg = ir.left{ceil((end + 1)/2)};
    result = render(renderableImg, mask, bg, render_mode);    
    imwrite(result, fullfile(storePath, ir.leftImageFiles(ir.start + ir.N/2).name));
    
end
%% Stop timer here
elapsed_time = toc


%% Write Movie to Disk
if store
    v = VideoWriter(dest,'Motion JPEG AVI');
    jpgs = dir(fullfile(storePath, '*.jpg'));
    open(v);
    for i=1:size(jpgs,1)
      I = imread(fullfile(jpgs(i).folder,jpgs(i).name)); %read the next image
      writeVideo(v,I); %write the image to file
    end
    close(v);
end