function [mask] = segmentation(left, right)
%Segmentation - Calculates the segmentation mask for a stereo image
% Two background models are approximated for the N image in the middle.
% One successor and one predecessor mask is generated with N/2 
% images and combined to the mask for the reference image.
%
% Syntax:  [mask] = segmentation(left,right)
%
% Inputs:
%    left - Cell array with frames of the left camera
%    right - Cell array with frames of the right camera
%
% Outputs:
%    mask - Segmentation mask as a logical matrix with image dimenions.
%           Foreground = 1 | Background = 0
%
% Other m-files required: none
% Subfunctions: getMask
% MAT-files required: none
%
% See also: challenge,  image_reader
% Author: Group 22
% email:
% July 2020; Last revision: 07-July-2020

N = size(left,1);
middle = ceil((N+1)/2);
imgsGrey = cellfun(@(x) rgb2gray(x), left, 'UniformOutput', false);

maskSuccessor = getMask(imgsGrey, middle, 15, 50, true);
maskPredecessor = getMask(imgsGrey, middle, 15, 50, false);

mask = logical(maskSuccessor .* maskPredecessor);

end


function mask = getMask(imgsGrey, middle, threshold, nhood, isSuccessor)
%GetMask - Calculates the mask for segmentation functions.
%
% Syntax: [mask] = getMask(imgsGrey, middle, threshold, nhood, isSuccessor)
%
% Inputs:
%    imgsGrey - N Grey images
%    middle - Image in the middle of all frames
%    threshold - Threshhold value for background - foreground comparison
%    nhood - All nonzero pixels of nhood belong to the neighborhood
%            for the morphological operation.
%    isSuccessor - Boolean for successor or predecessor mask selection

% Outputs:
%    mask - Segmentation mask as matrix with image dimenions.
%           Foreground = 1 | Background = 0

if isSuccessor == true
    imagesToLook = 1:middle -1;
else
    imagesToLook = middle + 1: size(imgsGrey,1);
end
background = mean(cat(3, imgsGrey{imagesToLook}),3);
meanDiff = double(imgsGrey{middle}) - background;
mask = abs(meanDiff) >= threshold;
mask = medfilt2(mask);
mask = imfill(imclose(mask, strel('disk',nhood)), 'holes');

end