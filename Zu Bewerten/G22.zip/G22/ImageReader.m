classdef ImageReader< handle
  % ImageReader   Summary of ImageReader
  % A class that holds properties of the source for images, index for the  
  % left camera, index for the right camera, the starting image number and 
  % the number of images, that will be used for segmentation.
  %
  % ImageReader Properties:
  %         src - Source folder
  %         L - Left Camera Number
  %         R - Right Camera Number
  %         start - Starting image Number
  %         N - Number of successor Images
  %         leftImageFiles - Array of left image files
  %         rightImageFiles - Array of right image files
  %         numImages - Shows the total number of images
  %         dimens - Image dimensions
  %         left - Cell array with elements from left images
  %         right - Cell array with elements from right images
  %
  % ImageReader Methods:
  %         ImageReader - Initialization method
  %
  %         next - Returns the left and right image tensors and loop.
  %
  %         getSubFolders - Deletes the non-directory files and the '.','..'
  %         files and returns the array of the folders.
  %
  %         fetchImageFiles - Assigns the images from left camera to
  %         leftImageFiles and assigns the images from the right camera to
  %         rightImageFiles.
  %
  %         initialRead - Inserts the left and right images to left cell 
  %         array and right cell array, respectively.   
  %         
  %
  % See also: challenge,  image_reader
  % Author: Group 22
  % email:
  % July 2020; Last revision: 07-July-2020
  properties
     src{isstring(src)};
     L{mustBeInteger,mustBeLessThan(L,3),mustBeGreaterThan(L,0)};
     R{mustBeInteger,mustBeLessThan(R,4),mustBeGreaterThan(R,1)};
     start{mustBeInteger,mustBeGreaterThan(start,0)}=1;
     N{mustBeInteger,mustBeGreaterThan(N,0)}=1;
     leftImageFiles;
     rightImageFiles;
     numImages;
     dimens;
     left;
     right;
  end
  methods 
      function obj = ImageReader(src, L, R, start,N)
          if ~exist(src,'dir')
              error('Please verify that you use a correct path at src!');
          end
            obj.src = src;
            obj.L = L;
            obj.R = R;
            if nargin > 4
                obj.start = start;
                obj.N = N;
            else
                obj.N = start;
            end
            fetchImageFiles(obj);
            initialRead(obj);
        end
      
      function [left,right,loop] = next(obj)
          % decide if the loop is 0 or 1
          % fail-safe number of successive images 
          obj.left(1) = [];
          obj.right(1) = [];
          obj.left{end+1} = imread(fullfile(obj.leftImageFiles(obj.start+obj.N).folder, ...
              obj.leftImageFiles(obj.start+obj.N).name));
          obj.right{end+1} = imread(fullfile(obj.rightImageFiles(obj.start+obj.N).folder, ...
              obj.rightImageFiles(obj.start+obj.N).name));
          obj.start = obj.start + 1;
          % put the left camera martices to left 
          left = obj.left;
          % put the right camera matrices to right
          right = obj.right;
          loop = (obj.start + obj.N) == obj.numImages;
      end
      
      function subFolders = getSubFolders(obj)
          files = dir(obj.src);
          % filter out non-directories
          files = files([files.isdir]);
          % remove current and previous paths
          files(ismember({files.name} , {'.','..'})) = [] ;
          
          subFolders = files;
      end
      
      function fetchImageFiles(obj)
          % List all folders that contain our data
          dataFolders = obj.getSubFolders();
          % Choose corresponding left and right folders
          leftImageFolder = dataFolders(obj.L);
          rightImageFolder = dataFolders(obj.R);
          % Fetching corresponding jpg files
          obj.leftImageFiles = dir(fullfile(obj.src, leftImageFolder.name, '*.jpg'));
          obj.rightImageFiles = dir(fullfile(obj.src, rightImageFolder.name, '*.jpg'));
          % Left and Right Image Numbers Assertion
          if size(obj.leftImageFiles,1)  ~= size(obj.rightImageFiles,1)
              error('Left and Right Images Mismatch')
          end
          % Store number of images and image dimensions to not fetch it every
          % run
          obj.numImages = size(obj.leftImageFiles,1);
          obj.dimens = size(imread(fullfile(obj.leftImageFiles(1).folder,...
              obj.leftImageFiles(1).name)));
      end

      function initialRead(obj)
          % create cell arrays
          obj.left = cell(obj.N,1);
          obj.right = cell(obj.N,1);
          % Assign the images to cell arrays
          for i = 0:obj.N-1
              obj.left{i+1} = imread(fullfile(obj.leftImageFiles(obj.start + i).folder, ...
                  obj.leftImageFiles(obj.start + i).name));
              obj.right{i+1} = imread(fullfile(obj.rightImageFiles(obj.start + i).folder, ...
                  obj.rightImageFiles(obj.start + i).name));
          end
      end      
      
  end
end
