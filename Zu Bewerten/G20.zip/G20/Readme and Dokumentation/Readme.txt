
Group: G20
members: Junpeng Chen, Shaoying Han, Hualin Tang, Zeyue Yang
emails: ge75xog@mytum.de, ge93noy@mytum.de, ge93yun@mytum.de, zeyue.yang@tum.de (ge75vuw@mytum.de)


###########################################################################################
############################## All functions are accessable through GUI ##############################
###########################################################################################

Enter the command start_gui to open the GUI.

step 1: Click the button 'Choose a scene folder'.
Select the scene folder,that need to be processed. After clicking, the corresponding path will be displayed in the text edit box on the side.

step 2: Click the button 'Choose a background image'.
Choose a image that replaces the background during rendering

step 3: Select the value of L and R.

step 4: Select the value of start.
The value of start specifies the frame number from which the scene should be played. If no value is specified, the program starts from frame 0. 
Because the user is not sure how many pictures are in the folder. So here are two ways to set start. 
One is to use the slider to select the start value. When the user wants to determine how many pictures there are, user can also move the slider to the very right, and the corresponding value will be displayed in the text box.
Another way, that user can directly write the start value in the text box, and press Enter to confirm, the slider of the slide bar will also move to the corresponding position.

step 5: Click the button 'Save'. 
To select the storage address of the video file composed of the rendered image. 
Note that this step must be selected before Start processing, otherwise the video file cannot be generated.

step 6: Select Mode

step 7: Click the button 'Start processing'.
After completing all the above parameter configuration and options. Click this button to start rendering work and video conversion.

step 8:  'frame finish' and 'render finish' 
There are two radio buttons on the edge of Start processing 'frame finish' and 'render finish' 
Users do not need to click these two buttons. Because the rendering process of the program will take a long time, you need to wait for all the pictures to be rendered. So the purpose of these two radio buttons is to show whether the rendering process is complete. When the rendering process is complete, the two radio buttons are automatically selected to remind the user to watch the video.

To play the video:
1. Start: When the 'frame finish' and 'render finish' buttons show that the rendering is complete. 
User can click the button 'Start' to play the video. 
This button can start playing video from the first frame.

2. Stop/Continue: Used to pause and continue playing video.

3. Loop: When checked, the video will loop. When unchecked, play to the last frame and then stop playing. 
To replay, user need to click the Start button again.


#################################################################################
############################## Description of subfunctions ##############################
#################################################################################

############### Image Reader ###############

class: ImageReader
properties: src, L, R, start, N
method:  ir = ImageReader(src0, L0, R0, varargin) 
The purpose of this method is create an object belonging to the ImageReader class.

Inputs:
src0: File path to a scene folder
L0: The value is 1 or 2. The camera with the number L0 serves as the left camera.
R0: The value is 2 or 3. The camera with the number R0 serves as the right camera. 
varargin includes two input parameters:
start: The parameter start means that from which frame number the scene  should be played. When no value is assigned, its default is 0.
N: The value N specifies how many successor images should be loaded per reading process. When no value is assigned, its default is 1.

Output:
ir: Object that is defined and belong to the ImageReader class.


method: [left,right,loop] = next(ir)

Input:
ir: previously defined object

Outputs:
left, right: Two tensors 'left' and 'right' of size (600x800x(N+1)*3) with N=4, 
which contain the pixel values of the starting frame and it's following N frames in the left and right cameras. 
loop: The loop value is set to 0 by default. If there are not enough images available in the folder, only the existing successors are returned and loop is set to 1

############### Segmentation ###############

Function: 
[mask, frame] = Segmentation(left, right)

Inputs: 
Two tensors 'left' and 'right' of size (600x800x(N+1)*3) with N=4, 
which contain the pixel values of the starting frame and it's following N frames in the left and right cameras. 

Outputs: 
The function gives back the variable 'mask' of size (600x800) for current frame chosen as the 3rd frame of 
the (N+1) frames of the left camera and stores the corresponding pixel values in variable 'frame'. 
Pixels that are assigned to the background are given the value 0. Pixels that belong to the foreground are given the value 1.

############### Rendering ############### 


function [result] = render(frame,mask,bg,render_mode)

Inputs:
frame: original video frame (600*800*3)
mask: corresponding mask achieved from segmentation (600*800)
bg: user defined picture/video frame (path can be configed through GUI)
render_mode: one of {'foreground','background','overlay','substitute'}, which can be chosen in the GUI

Output:
result: rendered image (600*800*3)


















