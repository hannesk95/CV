
function [result] = render(frame,mask,bg,render_mode)
  % Add function description here 
  % frame from left matrix 600*800*3 from 1 to N+1 
  % corresponding mask from segmentation 600*800
  % bg: user defined picture/video 
  % mode = {'foreground','background','overlay','substitute'} 
  % bg = double(imread('bg.jpg'));
   
  inv_mask = ~mask;
    
  
  switch render_mode
      case 'foreground'
          result = zeros(600,800,3);
          result(:,:,1) = mask.*frame(:,:,1);
          result(:,:,2) = mask.*frame(:,:,2);
          result(:,:,3) = mask.*frame(:,:,3);
      case 'background'
          result = zeros(600,800,3);
          result(:,:,1) = inv_mask.*frame(:,:,1);
          result(:,:,2) = inv_mask.*frame(:,:,2);
          result(:,:,3) = inv_mask.*frame(:,:,3);
      case 'overlay'
          fore_color(:,:,1) = 255.*ones(600,800);  % color of foreground: red
          fore_color(:,:,2) = zeros(600,800);
          fore_color(:,:,3) = zeros(600,800);
          
          back_color(:,:,1) = zeros(600,800); % color of background: blue
          back_color(:,:,2) = 80.*ones(600,800);
          back_color(:,:,3) = 255.*ones(600,800);
           
          fore_color(:,:,1) = mask.*fore_color(:,:,1);
          
          back_color(:,:,2) = inv_mask.*back_color(:,:,2);
          back_color(:,:,3) = inv_mask.*back_color(:,:,3);
          
          total = fore_color + back_color;
          result = double(imfuse(frame/256,total/256,'blend'));
      case 'substitute'
          temp1(:,:,1) =  inv_mask.*bg(:,:,1);
          temp1(:,:,2) =  inv_mask.*bg(:,:,2);
          temp1(:,:,3) =  inv_mask.*bg(:,:,3);
                
          temp2(:,:,1) = mask.*frame(:,:,1);
          temp2(:,:,2) = mask.*frame(:,:,2);
          temp2(:,:,3) = mask.*frame(:,:,3);
                
          result = temp1 + temp2;
              
      otherwise 
          error('Mode error: please choose mode from ''foreground'',''background'',''overlay'',''substitute''');
  end


end
