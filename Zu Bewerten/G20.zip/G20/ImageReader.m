classdef ImageReader < handle
  properties 
      src
      L
      R
      start
      N
  end
  methods
      function ir = ImageReader(src0,L0,R0,varargin) % varargin contains start and N
          p = inputParser;
          default_start = 0;
          default_N = 1;
          p.addParameter('start',default_start,@(x)validateattributes(x,{'numeric'},{'integer','>=',0}));
          p.addParameter('N',default_N,@(x)validateattributes(x,{'numeric'},{'integer','>=',1}));
          p.parse(varargin{:});
          if (L0==1 || L0==2) 
              ir.L = L0;
          else
              error('L must be 1 or 2');
          end
          if (R0==2 || R0==3) && (R0 ~= L0) 
              ir.R = R0;
          else
              error('R must be 2 or 3, and R,L must be different');
          end
          ir.src = src0;
          ir.start = p.Results.start;
          ir.N = p.Results.N;
      end
          
      function [left,right,loop] = next(ir)
          %check the system is windows or unix
          if isunix || ismac
              all_folder = strsplit(ir.src,'/');% split path with ‘/’
              scene_folder = char(all_folder(end));% get the szene  
              file_path_left = fullfile(ir.src,[scene_folder,'_','C',num2str(ir.L),'/']);% assemble a complete path
              file_path_right = fullfile(ir.src,[scene_folder,'_','C',num2str(ir.R),'/']);
          elseif ispc
              all_folder = strsplit(ir.src,'\');
              scene_folder = char(all_folder(end));
              file_path_left = fullfile(ir.src,[scene_folder,'_','C',num2str(ir.L),'\']);  
              file_path_right = fullfile(ir.src,[scene_folder,'_','C',num2str(ir.R),'\']); 
          end
           
          img_path_list_left = dir(strcat(file_path_left,'*.jpg'));% the structure to get all frames in the folder
          img_path_list_right = dir(strcat(file_path_right,'*.jpg'));
          img_num_left = length(img_path_list_left);%total number of frames
          left = zeros(600,800,(ir.N+1)*3);%pre allocate space for the matrix left
          right = zeros(600,800,(ir.N+1)*3); 
          
          %begin
          call = 0; 
          if (ir.start+1) + ir.N < img_num_left % the last frame is not reached
             loop = 0;
             for i = (ir.start+1) : (ir.start+1) + ir.N 
                 call = call + 1;
                 image_name_left = img_path_list_left(i).name;
                 left(:,:,(1+3*(call-1)):(3+3*(call-1))) = imread(strcat(file_path_left,image_name_left));
                 fprintf('%d,%s\n',loop,strcat(file_path_left,image_name_left));
                 image_name_right = img_path_list_right(i).name;
                 right(:,:,(1+3*(call-1)):(3+3*(call-1))) = imread(strcat(file_path_right,image_name_right));
                 fprintf('%d %s\n',loop,strcat(file_path_right,image_name_right));    
             end
             ir.start = ir.start+1;
          elseif (ir.start+1) + ir.N >= img_num_left % the last frame is reached
             loop = 1;
             for I = (ir.start+1) : img_num_left
                 call = call + 1;
                 image_name_left = img_path_list_left(I).name;
                 left(:,:,(1+3*(call-1)):(3+3*(call-1))) = imread(strcat(file_path_left,image_name_left));
                 fprintf('%d,%s\n',loop,strcat(file_path_left,image_name_left));
                 image_name_right = img_path_list_right(I).name;
                 right(:,:,(1+3*(call-1)):(3+3*(call-1))) = imread(strcat(file_path_right,image_name_right));
                 fprintf('%d %s\n',loop,strcat(file_path_right,image_name_right));        
             end
             ir.start = 0; %when reach the last frame, set start to 0
          end   
      end
  end
end