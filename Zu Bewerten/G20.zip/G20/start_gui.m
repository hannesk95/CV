function varargout = start_gui(varargin)
% START_GUI MATLAB code for start_gui.fig
%      START_GUI, by itself, creates a new START_GUI or raises the existing
%      singleton*.
%
%      H = START_GUI returns the handle to a new START_GUI or the handle to
%      the existing singleton*.
%
%      START_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in START_GUI.M with the given input arguments.
%
%      START_GUI('Property','Value',...) creates a new START_GUI or raises
%      ther
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before start_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to start_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help start_gui

% Last Modified by GUIDE v2.5 09-Jul-2020 01:11:53

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @start_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @start_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before start_gui is made visible.
function start_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to start_gui (see VARARGIN)
global Start Stop num_frames Stop_frame loop_gui flag %Initialize global variables
Start = 0; 
Stop = 0; 
num_frames = 0;
Stop_frame = 1;
loop_gui = 0;
flag = 0;
% Choose default command line output for start_gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes start_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = start_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
path = uigetdir; % A pop-up selection box to get the path of szene in the computer
set(handles.edit1,'string',path); %Display the obtained path on edit1
handles.src = path;%Store the obtained path in handles.src
guidata (hObject, handles);
set(handles.radiobutton5,'value',0);%At the beginning, set two prompt buttons that indicate the completion of the rendering process to 0 first
set(handles.radiobutton6,'value',0);


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,pathname,filterIndex] = uigetfile('*.jpg','choose bg');%Select a picture file with the file type jpg as the background
path = [pathname,filename]; %Get full picture path and name
handles.bg = path;%Save the path of the acquired background image to the variable handles.bg
guidata (hObject, handles);
set(handles.edit2,'string',path);%Display the obtained background image path and name in edit2
set(handles.radiobutton5,'value',0);
set(handles.radiobutton6,'value',0);


function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of radiobutton1
if get(handles.radiobutton1,'value')%获取radiobutton1的值，被选中则返回1
    L = 1;
    handles.L = L;%Store the selected L value
    guidata (hObject, handles);
    set(handles.radiobutton2,'value',0);%avoid two options being selected at the same time
end
L0 = handles.L;
src0 = handles.src;
if ispc
    all_folder = strsplit(src0,'\');
    scene_folder = char(all_folder(end));
    file_path_left = fullfile(src0,[scene_folder,'_','C',num2str(L0),'\']);
else 
    all_folder = strsplit(src0,'/');
    scene_folder = char(all_folder(end));
    file_path_left = fullfile(src0,[scene_folder,'_','C',num2str(L0),'/']);
end

img_path_list_left = dir(strcat(file_path_left,'*.jpg'));%Get all the picture files in this folder
max = length(img_path_list_left);%Get the number of all pictures in the folder

set(handles.slider1,'Max',max);%Set the upper bound of the slider
set(handles.slider1,'sliderstep',[1/max,1/max]);%Select the slide bar change step size, the change is required to be 1

set(handles.radiobutton5,'value',0);
set(handles.radiobutton6,'value',0);

% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of radiobutton2
if get(handles.radiobutton2,'value') 
    L = 2;
    handles.L = L;
    guidata (hObject, handles);
    set(handles.radiobutton1,'value',0);
end
set(handles.radiobutton5,'value',0);
set(handles.radiobutton6,'value',0);

% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of radiobutton3
if get(handles.radiobutton3,'value')
    R = 2;
    handles.R = R;
    guidata (hObject, handles);
    set(handles.radiobutton4,'value',0);
end
set(handles.radiobutton5,'value',0);
set(handles.radiobutton6,'value',0);

% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of radiobutton4
if get(handles.radiobutton4,'value')
    R = 3;
    handles.R = R;
    guidata (hObject, handles);
    set(handles.radiobutton3,'value',0);
end
set(handles.radiobutton5,'value',0);
set(handles.radiobutton6,'value',0);

% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
start_pre = get(handles.slider1,'Value');%Get the value of the slider
start = ceil(start_pre);
handles.start = start;
guidata (hObject, handles);
set(handles.edit3,'String',num2str(start));%Display the value of the slider in edit3
set(handles.radiobutton5,'value',0);
set(handles.radiobutton6,'value',0);


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double
slider = str2num(get(handles.edit3,'string'));%Enter the value of start directly in edit3
set(handles.slider1, 'Value',slider);%Stop the slider at the selected value
handles.start = slider;
guidata (hObject, handles);
set(handles.radiobutton5,'value',0);
set(handles.radiobutton6,'value',0);

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename_out, pathname_out] = uiputfile('output.avi');%A selection box pops up to select the storage path of the video
path_file_out = fullfile(pathname_out,filename_out);%Get the complete storage path
handles.path_file_out = path_file_out;
guidata (hObject, handles);
set(handles.radiobutton5,'value',0);
set(handles.radiobutton6,'value',0);

% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
set(handles.radiobutton5,'value',0);
set(handles.radiobutton6,'value',0);


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Click this button to start image rendering, and convert the rendered image into a video file
finished_frame = 0;
finished_render = 0;
set(handles.radiobutton5,'value',0);
set(handles.radiobutton6,'value',0);
mode_choosen = get(handles.popupmenu1, 'value');
if mode_choosen == 1
    render_mode = 'foreground';
elseif mode_choosen == 2
    render_mode = 'background';
elseif mode_choosen == 3
    render_mode = 'overlay';
elseif mode_choosen == 4
    render_mode = 'substitute';
end
%% segmentation 开始进行前景和背景分割
loop = 0;
count = 1;
firstloop = true;

bg = double(imread(handles.bg));%Assign background picture information to variable bg
src0 = handles.src; 
L0 = handles.L;
R0 = handles.R;
ir = ImageReader(src0,L0,R0,'start',handles.start,'N',4);%According to the selection parameters, build the object we need

while loop~= 1 %Start the loop, call the function segmentation to get the frame that needs to be rendered, and the frame after being split
    [left,right,loop] = next(ir);
    [mask, frame] = segmentation(left,right);
    if firstloop 
        firstloop = false;
        mask_sequence{1} = zeros(600,800);
        frame_sequence{1} = double(left(:,:,1:3));
        mask_sequence{2} = zeros(600,800);
        frame_sequence{2} = double(left(:,:,4:6));
    end
    mask_sequence{count}=mask; 
    frame_sequence{count}= frame;
    count = count+1;
    if loop == 1
        mask_sequence{count}=mask;
        frame_sequence{count}= frame;
        mask_sequence{count+1}=mask;
        frame_sequence{count+1}= frame;
    end
end
 %% render and videowriter
 
 myObj_after = VideoWriter(handles.path_file_out);%According to the previously selected save path, start generating video files
 myObj_after.FrameRate = 30;
 open(myObj_after);
 render_sequence = cell(1,numel(mask_sequence));%how many frames in total
 for i = 1:numel(mask_sequence)%Step by step insert frames
     render_sequence{1,i} = render(frame_sequence{i},mask_sequence{i},bg,render_mode);
     Frame = uint8(render_sequence{1,i});
     writeVideo(myObj_after,Frame);
     if i == numel(mask_sequence)%When the insertion of the last frame is completed, let finished_render be 1, indicating that the process has been completed
         finished_render = 1;
     end
 end 
 close(myObj_after);

 myObj_before = VideoWriter('before.avi');
 myObj_before.FrameRate = 30;
 open(myObj_before);
 for i = 1:numel(frame_sequence)
     frame = uint8(frame_sequence{i});
     writeVideo(myObj_before,frame);
     if  i == numel(frame_sequence)
         finished_frame = 1;
     end  
 end 
 close(myObj_before);
 %% check
 
 if finished_frame == 1%Tick the two radio buttons to indicate that the video has been generated and can start playing the video
  set(handles.radiobutton5,'value',1);
 end
 if finished_render == 1
  set(handles.radiobutton6,'value',1);
 end

% --- Executes on button press in radiobutton5.
function radiobutton5_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton5


% --- Executes on button press in radiobutton6.
function radiobutton6_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton6


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%This part is to achieve start playing, pause and loop playback

global Start Stop num_frames Stop_frame flag loop_gui 
Start = 1; 
num_frames = 0;%Used to indicate the number of frames currently playing
Stop = 0;
v = VideoReader('before.avi');%Read pre-rendered video
V = VideoReader(handles.path_file_out);%Read the rendered video
currAxes_1 = handles.axes1;
currAxes_2 = handles.axes2;
num = v.NumFrames;%Total frames of video
 while  (Start>0) 
     if loop_gui == 0 
         if num_frames == num %Without looping, when the video plays to the last frame, jump out of the loop and end the video
             break
         end
     end
     
     if mod(Stop,2) ~= 0 %According to the parity of the number of times the stop is pressed, it can be judged whether to pause or continue, if it is paused, it is odd, if it continues to play, it is even.
         Stop_frame = mod(num_frames,num);
         flag = 1;
     else
         flag = 0;
     end
     
     if flag == 1
         if Stop_frame == 0 %If the frame number of the video playback is the last frame when paused, the next playback starts from the first frame
             frame_stop_before = read(v,1);
             frame_stop_after = read(V,1);
         else %If the video is not the last frame when it is paused, when it is played again, it will start playing from the next frame that is paused
             frame_stop_before = read(v,Stop_frame); 
             frame_stop_after = read(V,Stop_frame); 
         end
       continue 
     end
     
     if (mod(num_frames,num) == 0) && (loop_gui == 1) && (num_frames ~= 0)
         frame1_before = read(v,1);
         frame1_after = read(V,1);
         image(frame1_before,'Parent' ,currAxes_1);
         image(frame1_after,'Parent' ,currAxes_2);
         currAxes_1.Visible = 'off';
         currAxes_2.Visible = 'off';
         pause(1/v.FrameRate);
         num_frames = 1;
         continue
     end
      
      vidFrame_before = readFrame(v);
      vidFrame_after = readFrame(V);
      num_frames = num_frames + 1;%Every time a frame is played, the frame number will increase by 1
      image(vidFrame_before,'Parent' ,currAxes_1);
      image(vidFrame_after,'Parent' ,currAxes_2);
      currAxes_1.Visible = 'off';
      currAxes_2.Visible = 'off';
      pause(1/v.FrameRate);
      flag = 0;   
 end

% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Stop 
Stop = Stop + 1;

% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of checkbox1
global loop_gui
if ( get(hObject,'Value') )
    loop_gui = 1;
else
    loop_gui = 0;
end
