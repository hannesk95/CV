%% Computer Vision Challenge 2020 challenge.m

%% Start timer here

t1 = clock;
%% Generate Movie
loop = 0;
count = 1;
firstloop = true;
ir = ImageReader(src,L,R,'start',start,'N',4); 
while loop ~= 1
  % Get next image tensors
  [left,right,loop] = next(ir);
  % Generate binary mask
  [mask, frame] = segmentation(left,right);
  if firstloop 
        firstloop = false;
        mask_sequence{1} = zeros(600,800);
        frame_sequence{1} = double(left(:,:,1:3));
        mask_sequence{2} = zeros(600,800);
        frame_sequence{2} = double(left(:,:,4:6));
   end
   mask_sequence{count}=mask;
   frame_sequence{count}= frame;
   count = count+1;
  % Render new frame
  if loop == 1
       mask_sequence{count}=mask;
       frame_sequence{count}= frame;
       mask_sequence{count+1}=mask;
       frame_sequence{count+1}= frame;
       
       render_sequence = cell(1,numel(mask_sequence));
       for i = 1:numel(mask_sequence)
           render_sequence{1,i} = render(frame_sequence{i},mask_sequence{i},bg,render_mode);
       end
  
  

  %% Write Movie to Disk
    if store
        myObj_after = VideoWriter(dest);
        myObj_after.FrameRate = 30;
        open(myObj_after);
        for i = 1:numel(mask_sequence)
            Frame = uint8(render_sequence{1,i});
            writeVideo(myObj_after,Frame);
        end 
        close(myObj_after);
    end
  end
end
%% Stop timer here
t2 = clock;
elapsed_time = etime(t2,t1);
