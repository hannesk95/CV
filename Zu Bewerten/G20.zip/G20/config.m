%% Computer Vision Challenge 2020 config.m

%% Generall Settings
% Group number:
group_number = 20;

% Group members:
members = {'Junpeng Chen', 'Shaoying Han','Hualin Tang','Zeyue Yang'};

% Email-Address (from Moodle!):
mail = {'ge75xog@mytum.de', 'ge93noy@mytum.de','ge93yun@mytum.de','zeyue.yang@tum.de'};


%% Setup Image Reader
% Specify Scene Folder
src = 'Path/to/my/ChokePoint/P1E_S1'; %Please enter an absolute path

% Select Cameras
L = 1;
R = 2;

% Choose a start point
%for test choose 2200
start = 2250;

% Choose the number of succseeding frames
N = 4;
%% Output Settings
% Output Path
dest = 'output.avi';

% Load Virual Background
bg = double(imread('bg.jpg'));

render_mode = 'substitute';

% Store Output?
store = true;
