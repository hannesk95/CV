function [mask, frame] = segmentation(left,right)
  % Add function description here
    [height,width,d] = size(right);
    %% Parameters   
    numberOfSamples         = 15;
    matchingThreshold       = 8; 
    matchingNumber          = 1; 
    samples = cell(1,numberOfSamples);
    mask = zeros(height,width);
    frame = zeros(height,width,d);
    %% ViBe Moving Object Detection
    for idx = 1:4
        i = 3;
        current_vidFrame = double(left(:,:,3*(i-1)+1:3*(i)));
        pre_vidFrame = double(left(:,:,3*(i-1-1)+1:3*(i-1)));
        next_vidFrame = double(left(:,:,3*(i)+1:3*(i+1)));
        prepre_vidFrame = double(left(:,:,3*(i-2-1)+1:3*(i-2)));
        nextnext_vidFrame = double(left(:,:,3*(i+1)+1:3*(i+2)));
        frame = current_vidFrame;
        if idx == 1
            samples{1} = pre_vidFrame;
            samples{2} = pre_vidFrame;
            for kk = 3:numberOfSamples
                samples{kk} = pre_vidFrame + randi([-8,8],height,width,3); % Initialization of samples
            end
        elseif  idx == 2
            samples{1} = next_vidFrame;
            samples{2} = next_vidFrame;
            for kk = 3:numberOfSamples
                samples{kk} = next_vidFrame + randi([-8,8],height,width,3); % Initialization of samples
            end
        elseif  idx == 3
            samples{1} = prepre_vidFrame;
            samples{2} = prepre_vidFrame;
            for kk = 3:numberOfSamples
                samples{kk} = prepre_vidFrame + randi([-8,8],height,width,3); % Initialization of samples
            end
        elseif  idx == 4
            samples{1} = nextnext_vidFrame;
            samples{2} = nextnext_vidFrame;
            for kk = 3:numberOfSamples
                samples{kk} = nextnext_vidFrame + randi([-8,8],height,width,3); % Initialization of samples
            end
        end
        %% Classification
        Mask = uint8(ones(height, width)*matchingNumber);
        
        for ii = 1:numberOfSamples
            distance = uint8(sqrt((current_vidFrame(:,:,1) - samples{ii}(:,:,1)).^2 ...
                                    + (current_vidFrame(:,:,2) - samples{ii}(:,:,2)).^2 ...
                                    + (current_vidFrame(:,:,3) - samples{ii}(:,:,3)).^2) <= matchingThreshold); % Compare the Euclidean distance with the threshold
            Mask = Mask - distance;
        end
        Mask = logical(Mask); % Create the mask. background:0,foreground:1
		
		% Fill the holes in the mask
        Mask_s{idx} = imfill(Mask, 'hole');
%         mask{idx} = Mask;

        
%         % Model update
%         for r = 2:height-1
%             for c = 2:width-1
%                 if mask{i}(r, c) == 0
%                     if updateFactor == 1 || floor(rand() * updateFactor) == 0
%                         samples{floor(rand() * numberOfSamples) + 1}(r, c, :) = current_vidFrame(r, c, :);
%                     end
% 
%                     if updateFactor == 1 || floor(rand() * updateFactor) == 0
%                         samples{floor(rand() * numberOfSamples) + 1}(r + neighbor(floor(rand() * 9) + 1), ...
%                             c + neighbor(floor(rand() * 9) + 1), :) = current_vidFrame(r, c, :);
%                     end
%                 end
%             end
%         end
        
    end
    for i = 1:height
        for j = 1:width
            if Mask_s{1}(i,j)==0 && Mask_s{2}(i,j)==0 && Mask_s{3}(i,j)==0 && Mask_s{4}(i,j)==0
                mask(i,j) = 0;
            else
                mask(i,j) = 1;
            end
        end
    end
    mask = logical(imfill(mask(:,:), 'hole'));
%         for ii = 1:numel(mask)
%             mask{ii}(:,:) = imfill(mask{ii}(:,:), 'hole');
%         end
end
