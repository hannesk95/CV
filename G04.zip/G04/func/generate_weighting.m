function mask = generate_weighting(width, height)
    mask = ones(height, width);
end

