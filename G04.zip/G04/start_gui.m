%% Clean up workspace and close all other figures
clear
close all
clc

%% Add function folder to MATLAB-path
addpath([pwd , '\func'])

%% Start the gui
% The actual gui is in the file gui.m
gui